<?php

/**
 * Plugin Name: Dark Reader - Beautiful Dark Mode for any Website
 * Plugin URI: https://bdthemes.com/plugin/dark-reader/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_Dark_Reader
 * Description: Add beautiful dark mode to your WordPress site using Dark Reader. Visit <a href="https://bdthemes.com/plugin/dark-reader/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_Dark_Reader">Dark Reader</a> for more advanced features.
 * Version: 1.1.7
 * Author: BdThemes
 * Author URI: https://bdthemes.com
 * Text Domain: dark-reader
 * License: GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

declare(strict_types=1);

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die(esc_html__('Direct access not permitted.', 'dark-reader'));
}

use Bdthemes\DarkReaderPro\DarkReaderPro;

/**
 * Main plugin class
 */
class Dark_Reader {

    /**
     * Plugin version
     *
     * @var string
     */
    private const VERSION = '1.1.7';

    /**
     * Plugin instance
     *
     * @var Dark_Reader|null
     */
    private static ?Dark_Reader $instance = null;

    /**
     * Plugin directory path
     *
     * @var string
     */
    private string $plugin_dir;

    /**
     * Plugin directory URL
     *
     * @var string
     */
    private string $plugin_url;

    /**
     * Initialize the plugin
     */
    private function __construct() {
        $this->plugin_dir = plugin_dir_path(__FILE__);
        $this->plugin_url = plugin_dir_url(__FILE__);

        $this->init_hooks();
        $this->load_dependencies();
    }

    /**
     * Get plugin instance
     *
     * @return Dark_Reader
     */
    public static function get_instance(): Dark_Reader {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize WordPress hooks
     *
     * @return void
     */
    private function init_hooks(): void {
        // Activation hook
        register_activation_hook(__FILE__, [$this, 'activate']);

        // Deactivation hook
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // Add settings link to plugin action links
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
    }

    /**
     * Load required dependencies
     *
     * @return void
     */
    private function load_dependencies(): void {
        require_once $this->plugin_dir . 'admin/admin-page.php';
        require_once $this->plugin_dir . 'includes/enqueue.php';
        require_once $this->plugin_dir . 'includes/shortcode.php';
        require_once $this->plugin_dir . 'includes/toggle-btn.php';
        require_once $this->plugin_dir . 'includes/biggopti.php';
        require_once $this->plugin_dir . 'includes/feed.php';

        // Hook for pro version integration
        do_action('dark_reader_loaded');
    }

    /**
     * Plugin activation
     *
     * @return void
     */
    public function activate(): void {
        flush_rewrite_rules();
        set_transient('_dark_reader_welcome_screen_activation_redirect', true, 30);
    }

    /**
     * Plugin deactivation
     *
     * @return void
     */
    public function deactivate(): void {
        flush_rewrite_rules();
    }

    /**
     * Get plugin directory path
     *
     * @return string
     */
    public function get_plugin_dir(): string {
        return $this->plugin_dir;
    }

    /**
     * Get plugin directory URL
     *
     * @return string
     */
    public function get_plugin_url(): string {
        return $this->plugin_url;
    }

    /**
     * Get plugin version
     *
     * @return string
     */
    public function get_version(): string {
        return self::VERSION;
    }

    /**
     * Check if pro version is active
     *
     * @return bool
     */
    public function is_pro_active(): bool {
        return class_exists('Bdthemes\DarkReaderPro\DarkReaderPro');
    }

    /**
     * Check if Pro is active and license is valid
     *
     * @return bool
     */
    public function has_valid_pro_license(): bool {
        if (!class_exists('\\Bdthemes\\DarkReaderPro\\DarkReaderPro')) {
            return false;
        }

        if (!method_exists('\\Bdthemes\\DarkReaderPro\\DarkReaderPro', 'is_license_valid')) {
            return false;
        }

        return \Bdthemes\DarkReaderPro\DarkReaderPro::is_license_valid() ?? false;
    }

    /**
     * Get available toggle styles (including pro styles)
     *
     * @return array
     */
    public function get_toggle_styles(): array {
        $styles = array(
            'default' => __('Default', 'dark-reader'),
            'round' => __('Round', 'dark-reader'),
            'switch' => __('Switch', 'dark-reader'),
            'toggle' => __('Toggle', 'dark-reader'),
            'minimal' => __('Minimal', 'dark-reader'),
            // 'slider' => __('Slider', 'dark-reader'),
        );

        // Allow pro version to add more styles
        return apply_filters('dark_reader_toggle_styles', $styles);
    }

    /**
     * Check if current page should show toggle button
     *
     * @return bool
     */
    public function should_show_toggle(): bool {
        $show = false;

        // Allow pro version to override visibility
        return apply_filters('dark_reader_should_show_toggle', $show);
    }

    /**
     * Add settings link to plugin action links
     *
     * @param array $links Existing plugin action links
     * @return array Modified plugin action links
     */
    public function add_settings_link(array $links): array {
        // Check if a Settings link already exists (Pro version might add it)
        foreach ($links as $link) {
            if (stripos($link, '>Settings<') !== false || stripos($link, '>settings<') !== false) {
                // Settings link already exists, don't add another one
                return $links;
            }
        }
        
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=dark-reader-settings')),
            esc_html__('Settings', 'dark-reader')
        );
        
        // Add settings link at the beginning of the array
        array_unshift($links, $settings_link);
        
        return $links;
    }
}

// Initialize the plugin
Dark_Reader::get_instance();
