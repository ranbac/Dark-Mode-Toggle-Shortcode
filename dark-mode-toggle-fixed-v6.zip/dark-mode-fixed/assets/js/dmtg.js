( function() {
	'use strict';

	var dmtg = dmtg || {};

	function dmtgDomReady( fn ) {
		if ( typeof fn !== 'function' ) {
			return;
		}

		if ( 'interactive' === document.readyState || 'complete' === document.readyState ) {
			return fn();
		}

		document.addEventListener( 'DOMContentLoaded', fn, false );
	}

	dmtg.setup = {
		config: [],

		init: function() {
			if ( darkmodetg ) {
				this.config = darkmodetg.config;
				this.addDarkmodeWidget();
			}
		},

		addDarkmodeWidget: function() {
			const config = this.config;
			const options = {
				bottom: config.bottom,
				left: config.left,
				top: config.top,
				right: config.right,
				width: config.width,
				height: config.height,
				borderRadius: config.borderRadius,
				fontSize: config.fontSize,
				time: config.time,
				mixColor: '#fff',
				backgroundColor: config.backgroundColor,
				buttonColorLight: config.buttonColorLight,
				buttonColorTLight: config.buttonColorTLight,
				buttonColorDark: config.buttonColorDark,
				buttonColorTDark: config.buttonColorTDark,
				saveInCookies: config.saveInCookies,
				fixFlick: config.fixFlick,
				label: config.label,
				autoMatchOsTheme: config.autoMatchOsTheme,
				onDefault: config.onDefault,
				buttonAriaLabel: config.buttonAriaLabel
			}

			// Gọi showWidget() để khởi tạo đầy đủ: CSS, layer classes, event listeners.
			new Darkmode( options ).showWidget();

			// Xóa floating button khỏi DOM ngay sau khi showWidget() chạy xong.
			var floatingBtn = document.getElementsByClassName( 'darkmode-toggle' )[0];
			if ( floatingBtn && floatingBtn.parentNode ) {
				floatingBtn.parentNode.removeChild( floatingBtn );
			}

			// Nếu hideMobile bật và đang ở màn hình nhỏ (≤640px): xóa layer khỏi DOM.
			// CSS !important không thể override inline style do JS set, nên phải xóa DOM.
			if ( config.hideMobile && window.matchMedia && window.matchMedia( '(max-width: 640px)' ).matches ) {
				var mobileLayer = document.getElementsByClassName( 'darkmode-layer' )[0];
				if ( mobileLayer && mobileLayer.parentNode ) {
					mobileLayer.parentNode.removeChild( mobileLayer );
				}
				var mobileBg = document.getElementsByClassName( 'darkmode-background' )[0];
				if ( mobileBg && mobileBg.parentNode ) {
					mobileBg.parentNode.removeChild( mobileBg );
				}
				return;
			}

			if ( document.body.classList.contains('darkmode--activated') ) {
				this.addBackground();
				if ( this.config.fixFlick ) {
					document.documentElement.classList.remove('dmtg-fade');
				}
			} else {
				this.removeBackground();
			}

			// Ẩn .darkmode-layer khi đang ở trạng thái "button" (dark mode chưa bật).
			// darkmode-js set inline style zIndex nên CSS !important không override được.
			// Dùng MutationObserver để sync trạng thái ẩn/hiện theo body class.
			var dmLayer = document.getElementsByClassName( 'darkmode-layer' )[0];
			if ( dmLayer ) {
				function dmtgSyncLayer() {
					if ( ! document.body.classList.contains( 'darkmode--activated' ) ) {
						dmLayer.style.setProperty( 'width', '0', 'important' );
						dmLayer.style.setProperty( 'height', '0', 'important' );
						dmLayer.style.setProperty( 'min-width', '0', 'important' );
						dmLayer.style.setProperty( 'min-height', '0', 'important' );
						dmLayer.style.setProperty( 'overflow', 'hidden', 'important' );
						dmLayer.style.setProperty( 'opacity', '0', 'important' );
						dmLayer.style.setProperty( 'pointer-events', 'none', 'important' );
						dmLayer.style.setProperty( 'border-radius', '0', 'important' );
					} else {
						dmLayer.style.removeProperty( 'width' );
						dmLayer.style.removeProperty( 'height' );
						dmLayer.style.removeProperty( 'min-width' );
						dmLayer.style.removeProperty( 'min-height' );
						dmLayer.style.removeProperty( 'overflow' );
						dmLayer.style.removeProperty( 'opacity' );
						dmLayer.style.removeProperty( 'pointer-events' );
						dmLayer.style.removeProperty( 'border-radius' );
					}
				}
				// Áp dụng ngay.
				dmtgSyncLayer();
				// Lắng nghe thay đổi class body để sync.
				if ( window.MutationObserver ) {
					new MutationObserver( dmtgSyncLayer ).observe(
						document.body,
						{ attributes: true, attributeFilter: [ 'class' ] }
					);
				}
			}

			var selector = '.darkmode-layer';
			if ( ! config.overrideStyles ) {
				selector = '.darkmode-toggle,.darkmode-layer';
			}
			const els = document.querySelectorAll( selector );
			[].forEach.call( els, function( el ) {
				el.style.zIndex = '9999999';
			} );
		},

		toggleBackground: function() {
			if ( document.body.classList.contains('darkmode--activated') ) {
				this.addBackground();
			} else {
				this.removeBackground();
			}
		},

		removeBackground: function() {
			const bg = document.getElementsByClassName( 'darkmode-background' )[0];
			if ( bg ) {
				bg.remove();
			}
		},

		addBackground: function() {
			if ( null !== document.querySelector( '.darkmode-background' ) ) { return; }
			var backgroundDiv = document.createElement( 'div' );
			backgroundDiv.setAttribute( 'class', 'darkmode-background' );
			document.body.insertBefore( backgroundDiv, document.body.firstChild );
		}
	};

	dmtgDomReady( function() {
		dmtg.setup.init();
	} );

} )();
