<?php

/**
 * Admin Page Template Part 2 for Dark Reader
 *
 * @package Dark Reader
 * @since 1.1.6
 */

use Bdthemes\DarkReaderPro\DarkReaderPro;
// Exit if accessed directly
if (!defined('WPINC')) {
    die('Direct access not permitted.');
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template variables are local scope, not globals

?>

<!-- Appearance Tab -->
<div id="dark-reader-tab-appearance" class="dark-reader-tab-content">
    <div class="dark-reader-dashboard-widgets">

        <div class="dark-reader-widget">
            <div class="dark-reader-switcher-content">
                <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
                    </svg>
                    Dark Mode
                </h3>
                <div class="dark-reader-widget-content">
                    <p>Enable dark mode by default for all visitors</p>
                </div>
            </div>
            <label class="dark-reader-toggle-switch">
                <input type="checkbox" name="dark_reader_default_dark_mode" value="1" <?php checked(1, $default_dark_mode); ?>>
                <span class="dark-reader-toggle-slider"></span>
            </label>
        </div>
    </div>

    <div class="dark-reader-settings-section">
        <h2>
            Brightness and Contrast
            <button type="button" class="dark-reader-reset-btn" id="dark-reader-reset-appearance">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"></path>
                    <path d="M21 3v5h-5"></path>
                    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"></path>
                    <path d="M3 21v-5h5"></path>
                </svg>
                Reset
            </button>
        </h2>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Brightness
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Adjust screen brightness in dark mode. Higher values make the screen brighter.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-range-slider">
                        <div class="dark-reader-range-slider-control">
                            <input type="range" min="50" max="150" name="dark_reader_brightness" value="<?php echo esc_attr($brightness); ?>" />
                            <span class="dark-reader-range-slider-value"><?php echo esc_html($brightness); ?>%</span>
                        </div>
                        <span class="description">Adjust screen brightness in dark mode (50% - 150%)</span>
                    </div>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Contrast
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Adjust contrast in dark mode. Higher values increase the difference between light and dark elements.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-range-slider">
                        <div class="dark-reader-range-slider-control">
                            <input type="range" min="50" max="150" name="dark_reader_contrast" value="<?php echo esc_attr($contrast); ?>" />
                            <span class="dark-reader-range-slider-value"><?php echo esc_html($contrast); ?>%</span>
                        </div>
                        <span class="description">Adjust contrast in dark mode (50% - 150%)</span>
                    </div>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Sepia
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Add sepia filter to reduce blue light. Higher values add more sepia tone.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-range-slider">
                        <div class="dark-reader-range-slider-control">
                            <input type="range" min="0" max="100" name="dark_reader_sepia" value="<?php echo esc_attr($sepia); ?>" />
                            <span class="dark-reader-range-slider-value"><?php echo esc_html($sepia); ?>%</span>
                        </div>
                        <span class="description">Add sepia filter to reduce blue light (0% - 100%)</span>
                    </div>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Grayscale
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Add grayscale filter to remove colors. 100% makes the page completely black and white.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-range-slider">
                        <div class="dark-reader-range-slider-control">
                            <input type="range" min="0" max="100" name="dark_reader_grayscale" value="<?php echo esc_attr($grayscale); ?>" />
                            <span class="dark-reader-range-slider-value"><?php echo esc_html($grayscale); ?>%</span>
                        </div>
                        <span class="description">Add grayscale filter (0% - 100%)</span>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- Toggle Button Tab -->
<div id="dark-reader-tab-toggle" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>Toggle Button Position</h2>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Position
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Choose where to place the toggle button on your website.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-position-toggles">
                        <input type="hidden" name="dark_reader_toggle_position" id="dark_reader_toggle_position" value="<?php echo esc_attr($position); ?>">

                        <label class="position-toggle-btn <?php echo $position === 'top-left' ? 'active' : ''; ?>" data-position="top-left">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <circle cx="8" cy="8" r="3"></circle>
                            </svg>
                            <span>Top Left</span>
                        </label>

                        <label class="position-toggle-btn <?php echo $position === 'top-right' ? 'active' : ''; ?>" data-position="top-right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <circle cx="16" cy="8" r="3"></circle>
                            </svg>
                            <span>Top Right</span>
                        </label>

                        <label class="position-toggle-btn <?php echo $position === 'bottom-left' ? 'active' : ''; ?>" data-position="bottom-left">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <circle cx="8" cy="16" r="3"></circle>
                            </svg>
                            <span>Bottom Left</span>
                        </label>

                        <label class="position-toggle-btn <?php echo $position === 'bottom-right' ? 'active' : ''; ?>" data-position="bottom-right">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <circle cx="16" cy="16" r="3"></circle>
                            </svg>
                            <span>Bottom Right</span>
                        </label>
                    </div>
                    <span class="description">Choose where to place the toggle button on your website</span>
                </td>
            </tr>
        </table>
    </div>

    <div class="dark-reader-settings-section">
        <h2>Toggle Button Style</h2>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Style
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Choose the appearance of the toggle button.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-style-options">
                        <!-- Free Styles -->
                        <label class="dark-reader-style-option <?php echo $current_style === 'default' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="default" <?php checked('default', $current_style); ?> />
                            <span class="dark-reader-style-preview default">
                                <span class="preview-button">
                                    <span class="preview-icon">☀️</span>
                                </span>
                                <span class="dark-reader-style-name">Default</span>
                            </span>
                        </label>

                        <label class="dark-reader-style-option <?php echo $current_style === 'round' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="round" <?php checked('round', $current_style); ?> />
                            <span class="dark-reader-style-preview round">
                                <span class="preview-button round">
                                    <span class="preview-icon">☀️</span>
                                </span>
                                <span class="dark-reader-style-name">Round</span>
                            </span>
                        </label>

                        <label class="dark-reader-style-option <?php echo $current_style === 'switch' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="switch" <?php checked('switch', $current_style); ?> />
                            <span class="dark-reader-style-preview switch">
                                <span class="preview-switch">
                                    <span class="preview-track"></span>
                                    <span class="preview-thumb"></span>
                                </span>
                                <span class="dark-reader-style-name">Switch</span>
                            </span>
                        </label>

                        <label class="dark-reader-style-option <?php echo $current_style === 'toggle' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="toggle" <?php checked('toggle', $current_style); ?> />
                            <span class="dark-reader-style-preview toggle">
                                <span class="preview-toggle">
                                    <span class="preview-toggle-track">
                                        <span class="preview-toggle-sun">☀️</span>
                                        <span class="preview-toggle-moon">🌙</span>
                                    </span>
                                    <span class="preview-toggle-thumb"></span>
                                </span>
                                <span class="dark-reader-style-name">Toggle</span>
                            </span>
                        </label>

                        <label class="dark-reader-style-option <?php echo $current_style === 'minimal' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="minimal" <?php checked('minimal', $current_style); ?> />
                            <span class="dark-reader-style-preview minimal">
                                <span class="preview-button minimal">
                                    <span class="preview-minimal-icon"></span>
                                </span>
                                <span class="dark-reader-style-name">Minimal</span>
                            </span>
                        </label>
<!-- 
                        <label class="dark-reader-style-option  echo $current_style === 'slider' ? 'selected' : ''; ?>">
                            <input type="radio" name="dark_reader_toggle_style" value="slider"  checked('slider', $current_style); ?> />
                            <span class="dark-reader-style-preview slider">
                                <span class="preview-slider">
                                    <span class="preview-slider-background"></span>
                                    <span class="preview-slider-track">
                                        <span class="preview-slider-sun">☀️</span>
                                        <span class="preview-slider-moon">🌙</span>
                                    </span>
                                    <span class="preview-slider-thumb"></span>
                                </span>
                                <span class="dark-reader-style-name">Slider</span>
                            </span>
                        </label> -->
                        
                    </div>
                </td>
            </tr>
            <?php if (Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                <!-- Pro Styles Section -->
                <tr valign="top">
                    <th scope="row">
                        Pro Styles
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Choose the pro appearance of the toggle button.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-pro-styles-grid">
                            <?php
                            $available_styles = Dark_Reader::get_instance()->get_toggle_styles();
                            $pro_styles = ['modern-slider', 'text-toggle', 'flipflop-toggle', 'ios-toggle', 'ios-toggle-icon', 'liquid-glass'];

                            foreach ($pro_styles as $style_key):
                                if (isset($available_styles[$style_key])):
                                    $preview_content = '';
                                    switch ($style_key) {
                                        case 'modern-slider':
                                            $preview_content = '<div class="preview-modern-slider">
                                        <div class="modern-slider-container">
                                            <div class="modern-slider-track">
                                                <span class="modern-slider-sun">☀️</span>
                                                <span class="modern-slider-moon">🌙</span>
                                                <div class="modern-slider-thumb"></div>
                                            </div>
                                        </div>
                                    </div>';
                                            break;
                                        case 'text-toggle':
                                            $preview_content = '<div class="preview-text-toggle">
                                        <div class="text-toggle-bar">
                                            <span class="toggle-text on">Light</span>
                                            <span class="toggle-text off">Dark</span>
                                        </div>
                                    </div>';
                                            break;
                                        case 'flipflop-toggle':
                                            $preview_content = '<div class="preview-flipflop-toggle">
                                        <div class="flipflop-circle">
                                            <div class="flipflop-side front">
                                                <span class="flipflop-icon">☀️</span>
                                            </div>
                                            <div class="flipflop-side back">
                                                <span class="flipflop-icon">🌙</span>
                                            </div>
                                        </div>
                                    </div>';
                                            break;
                                        case 'ios-toggle':
                                            $preview_content = '<div class="preview-ios-toggle">
                                        <div class="ios-toggle-bar">
                                            <div class="toggle-text-container">
                                                <span class="ios-text off">Dark</span>
                                                <span class="ios-text on">Light</span>
                                                <div class="ios-toggle-handle"></div>
                                            </div>
                                        </div>
                                    </div>';
                                            break;
                                        case 'ios-toggle-icon':
                                            $preview_content = '<div class="preview-ios-toggle-icon">
                                        <div class="ios-toggle-bar">
                                            <div class="toggle-text-container">
                                                <span class="ios-text off">🌙</span>
                                                <span class="ios-text on">☀️</span>
                                                <div class="ios-toggle-handle"></div>
                                            </div>
                                        </div>
                                    </div>';
                                            break;
                                        case 'liquid-glass':
                                            $preview_content = '<div class="preview-liquid-glass">
                                        <div class="liquid-glass-preview">
                                            <div class="liquid-glass-track">
                                                <span class="liquid-glass-icon">
                                                    <span class="liquid-glass-sun">☀️</span>
                                                    <span class="liquid-glass-moon">🌙</span>
                                                </span>
                                                <div class="liquid-glass-thumb"></div>
                                            </div>
                                        </div>
                                    </div>';
                                            break;
                                    }
                            ?>
                                    <label class="dark-reader-style-option pro-style <?php echo $current_style === $style_key ? 'selected' : ''; ?>">
                                        <input type="radio" name="dark_reader_toggle_style" value="<?php echo esc_attr($style_key); ?>" <?php checked($style_key, $current_style); ?> />
                                        <span class="dark-reader-style-preview <?php echo esc_attr($style_key); ?>">
                                            <span class="preview-button pro-preview">
                                                <?php echo wp_kses_post($preview_content); ?>
                                                <!-- <span class="pro-badge">PRO</span> -->
                                            </span>
                                            <span class="dark-reader-style-name"><?php echo esc_html($available_styles[$style_key]); ?></span>
                                        </span>
                                    </label>
                            <?php
                                endif;
                            endforeach;
                            ?>
                        </div>
                    </td>
                </tr>
                <!-- Custom Toggle Button Section -->
                <tr valign="top">
                    <th scope="row">
                        Custom Toggle Button
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Create your own custom toggle button with emoji, SVG, and custom styling.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-custom-toggle-section">
                            <label class="dark-reader-style-option <?php echo $current_style === 'custom' ? 'selected' : ''; ?>">
                                <input type="radio" name="dark_reader_toggle_style" value="custom" <?php checked('custom', $current_style); ?> />
                                <span class="dark-reader-style-preview custom">
                                    <span class="preview-button pro-preview">
                                        <div class="preview-custom-toggle">
                                            <span class="custom-toggle-preview-icon">⚡</span>
                                        </div>
                                    </span>
                                    <span class="dark-reader-style-name">Custom Toggle</span>
                                </span>
                            </label>
                            
                            <!-- Custom Toggle Settings (always shown when license is active) -->
                            <div class="dark-reader-custom-toggle-settings">
                                <button type="button" class="dark-reader-btn dark-reader-btn-primary dark-reader-open-custom-toggle-editor">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                    Customize Toggle Button
                                </button>
                                <p class="description">Click to open the custom toggle button editor where you can set icons, colors, and more.</p>
                            </div>
                        </div>
                    </td>
                <?php elseif (Dark_Reader::get_instance()->is_pro_active()): ?>
                    <!-- Pro Styles Section -->
                <tr valign="top">
                    <th scope="row">
                        🔒 Pro Styles (6 Available)
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Choose the pro appearance of the toggle button.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-pro-styles-section">
                            <div class="dark-reader-pro-styles-grid">
                                <?php
                                $available_styles = Dark_Reader::get_instance()->get_toggle_styles();
                                $pro_styles = ['modern-slider', 'text-toggle', 'flipflop-toggle', 'ios-toggle', 'ios-toggle-icon', 'liquid-glass'];

                                foreach ($pro_styles as $style_key):
                                    if (isset($available_styles[$style_key])):
                                        $preview_content = '';
                                        switch ($style_key) {
                                            case 'modern-slider':
                                                $preview_content = '<div class="preview-modern-slider">
                                                <div class="modern-slider-container">
                                                    <div class="modern-slider-track">
                                                        <span class="modern-slider-sun">☀️</span>
                                                        <span class="modern-slider-moon">🌙</span>
                                                        <div class="modern-slider-thumb"></div>
                                                    </div>
                                                </div>
                                            </div>';
                                                break;
                                            case 'text-toggle':
                                                $preview_content = '<div class="preview-text-toggle">
                                                <div class="text-toggle-bar">
                                                    <span class="toggle-text on">Light</span>
                                                    <span class="toggle-text off">Dark</span>
                                                </div>
                                            </div>';
                                                break;
                                            case 'flipflop-toggle':
                                                $preview_content = '<div class="preview-flipflop-toggle">
                                                <div class="flipflop-circle">
                                                    <div class="flipflop-side front">
                                                        <span class="flipflop-icon">☀️</span>
                                                    </div>
                                                    <div class="flipflop-side back">
                                                        <span class="flipflop-icon">🌙</span>
                                                    </div>
                                                </div>
                                            </div>';
                                                break;
                                            case 'ios-toggle':
                                                $preview_content = '<div class="preview-ios-toggle">
                                                <div class="ios-toggle-bar">
                                                    <div class="toggle-text-container">
                                                        <span class="ios-text off">Dark</span>
                                                        <span class="ios-text on">Light</span>
                                                        <div class="ios-toggle-handle"></div>
                                                    </div>
                                                </div>
                                            </div>';
                                                break;
                                            case 'ios-toggle-icon':
                                                $preview_content = '<div class="preview-ios-toggle-icon">
                                                <div class="ios-toggle-bar">
                                                    <div class="toggle-text-container">
                                                        <span class="ios-text off">🌙</span>
                                                        <span class="ios-text on">☀️</span>
                                                        <div class="ios-toggle-handle"></div>
                                                    </div>
                                                </div>
                                            </div>';
                                                break;
                                            case 'liquid-glass':
                                                $preview_content = '<div class="preview-liquid-glass">
                                                <div class="liquid-glass-preview">
                                                    <div class="liquid-glass-track">
                                                        <div class="liquid-glass-thumb"></div>
                                                    </div>
                                                </div>
                                            </div>';
                                                break;
                                        }
                                ?>
                                        <div class="dark-reader-style-option-lock pro-style">
                                            <span class="dark-reader-style-preview <?php echo esc_attr($style_key); ?>">
                                                <span class="preview-button pro-preview">
                                                    <?php echo wp_kses_post($preview_content); ?>
                                                    <?php if ($style_key !== 'liquid-glass'): ?>
                                                    <span class="pro-badge">
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                            stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                            aria-hidden="true" role="img">
                                                            <rect x="4" y="10" width="16" height="10" rx="2" />
                                                            <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                            <circle cx="12" cy="15" r="1.5" />
                                                        </svg>
                                                    </span>
                                                    <?php endif; ?>
                                                </span>
                                                <?php if ($style_key === 'liquid-glass'): ?>
                                                <span class="pro-badge">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                        stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                        aria-hidden="true" role="img">
                                                        <rect x="4" y="10" width="16" height="10" rx="2" />
                                                        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                        <circle cx="12" cy="15" r="1.5" />
                                                    </svg>
                                                </span>
                                                <?php endif; ?>
                                                <span class="dark-reader-style-name"><?php echo esc_html($available_styles[$style_key]); ?></span>
                                            </span>
                                        </div>
                                <?php
                                    endif;
                                endforeach;
                                ?>
                            </div>
                            <p class="pro-upgrade-message">
                                <strong>Activate your license to unlock 6 advanced toggle styles!</strong>
                            </p>
                        </div>
                    </td>
                </tr>
                <!-- Custom Toggle Preview (Locked when license invalid) -->          
                <tr valign="top">
                    <th scope="row">
                        🔒 Custom Toggle Button
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Create your own custom toggle button with emoji, SVG, and custom styling.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-custom-toggle-section">
                            <div class="dark-reader-style-option-lock pro-style">
                                <span class="dark-reader-style-preview custom">
                                    <span class="preview-button pro-preview">
                                        <div class="preview-custom-toggle">
                                            <span class="custom-toggle-preview-icon">⚡</span>
                                        </div>
                                        <span class="pro-badge">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                aria-hidden="true" role="img">
                                                <rect x="4" y="10" width="16" height="10" rx="2" />
                                                <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                <circle cx="12" cy="15" r="1.5" />
                                            </svg>
                                        </span>
                                    </span>
                                    <span class="dark-reader-style-name">Custom Toggle</span>
                                </span>
                            </div>
                            <p class="pro-upgrade-message">
                                <strong>Activate your license to unlock the custom toggle button!</strong>
                            </p>
                        </div>
                    </td>
                <?php else: ?>
                <!-- Pro not activated - Show locked previews -->
                <tr valign="top">
                    <th scope="row">
                        🔒 Pro Styles (6 Available)
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Upgrade to Pro to unlock advanced toggle styles.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-pro-styles-section">
                            <div class="dark-reader-pro-styles-grid">
                                <?php
                                $pro_styles_preview = [
                                    'modern-slider' => [
                                        'name' => 'Modern Slider',
                                        'preview' => '<div class="preview-modern-slider">
                                            <div class="modern-slider-container">
                                                <div class="modern-slider-track">
                                                    <span class="modern-slider-sun">☀️</span>
                                                    <span class="modern-slider-moon">🌙</span>
                                                    <div class="modern-slider-thumb"></div>
                                                </div>
                                            </div>
                                        </div>'
                                    ],
                                    'text-toggle' => [
                                        'name' => 'Text Toggle',
                                        'preview' => '<div class="preview-text-toggle">
                                            <div class="text-toggle-bar">
                                                <span class="toggle-text on">Light</span>
                                                <span class="toggle-text off">Dark</span>
                                            </div>
                                        </div>'
                                    ],
                                    'flipflop-toggle' => [
                                        'name' => 'FlipFlop Toggle',
                                        'preview' => '<div class="preview-flipflop-toggle">
                                            <div class="flipflop-circle">
                                                <div class="flipflop-side front">
                                                    <span class="flipflop-icon">☀️</span>
                                                </div>
                                                <div class="flipflop-side back">
                                                    <span class="flipflop-icon">🌙</span>
                                                </div>
                                            </div>
                                        </div>'
                                    ],
                                    'ios-toggle' => [
                                        'name' => 'iOS Toggle',
                                        'preview' => '<div class="preview-ios-toggle">
                                            <div class="ios-toggle-bar">
                                                <div class="toggle-text-container">
                                                    <span class="ios-text off">Dark</span>
                                                    <span class="ios-text on">Light</span>
                                                    <div class="ios-toggle-handle"></div>
                                                </div>
                                            </div>
                                        </div>'
                                    ],
                                    'ios-toggle-icon' => [
                                        'name' => 'iOS Toggle Icon',
                                        'preview' => '<div class="preview-ios-toggle-icon">
                                            <div class="ios-toggle-bar">
                                                <div class="toggle-text-container">
                                                    <span class="ios-text off">🌙</span>
                                                    <span class="ios-text on">☀️</span>
                                                    <div class="ios-toggle-handle"></div>
                                                </div>
                                            </div>
                                        </div>'
                                    ],
                                    'liquid-glass' => [
                                        'name' => 'Liquid Glass',
                                        'preview' => '<div class="preview-liquid-glass">
                                            <div class="liquid-glass-preview">

                                                <div class="liquid-glass-track">
                                                    <div class="liquid-glass-thumb"></div>
                                                </div>
                                            </div>
                                        </div>'
                                    ]
                                ];

                                foreach ($pro_styles_preview as $style_key => $style_data):
                                ?>
                                    <div class="dark-reader-style-option-lock pro-style">
                                        <span class="dark-reader-style-preview <?php echo esc_attr($style_key); ?>">
                                            <span class="preview-button pro-preview">
                                                <?php echo wp_kses_post($style_data['preview']); ?>
                                                <?php if ($style_key !== 'liquid-glass'): ?>
                                                <span class="pro-badge">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                        stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                        aria-hidden="true" role="img">
                                                        <rect x="4" y="10" width="16" height="10" rx="2" />
                                                        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                        <circle cx="12" cy="15" r="1.5" />
                                                    </svg>
                                                </span>
                                                <?php endif; ?>
                                            </span>
                                            <?php if ($style_key === 'liquid-glass'): ?>
                                            <span class="pro-badge">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    aria-hidden="true" role="img">
                                                    <rect x="4" y="10" width="16" height="10" rx="2" />
                                                    <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                    <circle cx="12" cy="15" r="1.5" />
                                                </svg>
                                            </span>
                                            <?php endif; ?>
                                            <span class="dark-reader-style-name"><?php echo esc_html($style_data['name']); ?></span>
                                        </span>
                                    </div>
                                <?php
                                endforeach;
                                ?>
                            </div>
                            <p class="pro-upgrade-message">
                                <strong>Upgrade to Pro to unlock 6 advanced toggle styles!</strong>
                            </p>
                        </div>
                    </td>
                </tr>
                <!-- Custom Toggle Preview (Locked) -->
                <tr valign="top">
                    <th scope="row">
                        🔒 Custom Toggle Button
                        <div class="dark-reader-tooltip">
                            <span class="dark-reader-tooltip-icon">?</span>
                            <span class="dark-reader-tooltip-text">Create your own custom toggle button with emoji, SVG, and custom styling.</span>
                        </div>
                    </th>
                    <td>
                        <div class="dark-reader-custom-toggle-section">
                            <div class="dark-reader-style-option-lock pro-style">
                                <span class="dark-reader-style-preview custom">
                                    <span class="preview-button pro-preview">
                                        <div class="preview-custom-toggle">
                                            <span class="custom-toggle-preview-icon">⚡</span>
                                        </div>
                                        <span class="pro-badge">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                stroke="orange" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                aria-hidden="true" role="img">
                                                <rect x="4" y="10" width="16" height="10" rx="2" />
                                                <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                                                <circle cx="12" cy="15" r="1.5" />
                                            </svg>
                                        </span>
                                    </span>
                                    <span class="dark-reader-style-name">Custom Toggle</span>
                                </span>
                            </div>
                            <p class="pro-upgrade-message">
                                <strong>Upgrade to Pro to create your own custom toggle button!</strong>
                            </p>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
        </table>
    </div>
</div>

<!-- Advanced Tab -->
<div id="dark-reader-tab-advanced" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>System and Performance</h2>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Use System Color Scheme
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Enable dark mode automatically when the system is set to dark mode</span>
                    </div>
                </th>
                <td>
                    <label class="dark-reader-toggle-switch">
                        <input type="checkbox" name="dark_reader_use_system_color_scheme" value="1" <?php checked(1, $use_system_color_scheme); ?>>
                        <span class="dark-reader-toggle-slider"></span>
                    </label>
                    <span class="description">Enable dark mode when the device is set to dark mode</span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Enable for PDFs
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Apply dark mode to PDF documents viewed in the browser</span>
                    </div>
                </th>
                <td>
                    <label class="dark-reader-toggle-switch">
                        <input type="checkbox" name="dark_reader_enable_for_pdfs" value="1" <?php checked(1, $enable_for_pdfs); ?>>
                        <span class="dark-reader-toggle-slider"></span>
                    </label>
                    <span class="description">Apply dark mode to PDF documents</span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Apply Immediately
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Apply dark mode immediately to dynamic content on the page. Disable for better performance.</span>
                    </div>
                </th>
                <td>
                    <label class="dark-reader-toggle-switch">
                        <input type="checkbox" name="dark_reader_immediate_modify" value="1" <?php checked(1, $immediate_modify); ?>>
                        <span class="dark-reader-toggle-slider"></span>
                    </label>
                    <span class="description">Apply dark mode to dynamic content immediately</span>
                </td>
            </tr>
        </table>
    </div>

    <div class="dark-reader-settings-section">
        <h2>Advanced Filters</h2>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Filter Mode
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Choose between dark mode (more contrast) or dimmed mode (less contrast)</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-radio-group">
                        <label>
                            <input type="radio" name="dark_reader_filter_mode" value="0" <?php checked(0, $filter_mode); ?>>
                            <span>Dimmed Mode</span>
                        </label>
                        <label>
                            <input type="radio" name="dark_reader_filter_mode" value="1" <?php checked(1, $filter_mode); ?>>
                            <span>Dark Mode</span>
                        </label>
                    </div>
                    <span class="description">Dimmed mode provides less contrast than dark mode</span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Text Stroke
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Increase text stroke to make text look bolder (0-1px)</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-range-slider">
                        <div class="dark-reader-range-slider-control">
                            <input type="range" min="0" max="1" step="0.1" name="dark_reader_text_stroke" value="<?php echo esc_attr($text_stroke); ?>" />
                            <span class="dark-reader-range-slider-value"><?php echo esc_html($text_stroke); ?>px</span>
                        </div>
                        <span class="description">Apply stroke to text to make it look bolder (0-1px)</span>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- Colors Tab -->
<div id="dark-reader-tab-colors" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>Dark Mode Colors</h2>
        <p>Define custom colors for dark mode. Leave fields empty to use the default color algorithms.</p>
        <table class="dark-reader-form-table">
            <tr valign="top">
                <th scope="row">
                    Background Color
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Custom background color for dark mode. Default is #141414.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-color-picker-wrapper colors-tab">
                        <div class="dark-reader-color-preview"></div>
                        <input type="text" class="dark-reader-color-picker" name="dark_reader_dark_scheme_background" value="<?php echo esc_attr($dark_scheme_bg); ?>" placeholder="#141414" />
                    </div>
                    <span class="description">Custom background color for dark mode (e.g., #141414). This will override Dark Reader's automatic color generation.</span>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Text Color
                    <div class="dark-reader-tooltip">
                        <span class="dark-reader-tooltip-icon">?</span>
                        <span class="dark-reader-tooltip-text">Custom text color for dark mode. Default is #e8e8e8.</span>
                    </div>
                </th>
                <td>
                    <div class="dark-reader-color-picker-wrapper colors-tab">
                        <div class="dark-reader-color-preview"></div>
                        <input type="text" class="dark-reader-color-picker" name="dark_reader_dark_scheme_text" value="<?php echo esc_attr($dark_scheme_text); ?>" placeholder="#e8e8e8" />
                    </div>
                    <span class="description">Custom text color for dark mode (e.g., #e8e8e8). This will override Dark Reader's automatic color generation.</span>
                </td>
            </tr>

        </table>
        <!-- Notice for custom colors -->
        <div class="dark-reader-notice">
            <span class="dark-reader-notice-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
                </svg>
            </span>
            <div class="dark-reader-notice-content">
                <p>Changes to custom colors require saving settings, refreshing your site, and clearing cache (if using a caching plugin).</p>
            </div>
        </div>
    </div>


</div>

<!-- Help Tab -->
<div id="dark-reader-tab-help" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>Documentation</h2>

        <div class="dark-reader-help-box">
            <h3>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                </svg>
                How to Use the Shortcode
            </h3>
            <p>You can add a dark mode toggle button anywhere in your content using the <code>[dark_reader_toggle]</code> shortcode. This is useful for adding the toggle to specific pages, posts, or widgets.</p>
        </div>

        <div class="dark-reader-help-box">
            <h3>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 7V4a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3"></path>
                    <path d="M12 14V5"></path>
                    <path d="m8 9 4 5 4-5"></path>
                    <rect width="20" height="8" x="2" y="15" rx="1"></rect>
                </svg>
                Shortcode
            </h3>
            <div class="dark-reader-widget-content">
                <p class="dark-reader-shortcode-description">Use this shortcode to add a toggle button anywhere in your content:</p>
                <div class="dark-reader-shortcode-display">
                    <code>[dark_reader_toggle]</code>
                    <button class="dark-reader-copy-btn">
                        <span>Copy</span>
                        <span class="dark-reader-checkmark"></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="dark-reader-help-box">
            <h3>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
                Common Issues
            </h3>
            <ul>
                <li><strong>Toggle button not appearing:</strong> Make sure your theme has a proper wp_footer() call in the footer template.</li>
                <li><strong>Dark mode not working with caching:</strong> If you're using a caching plugin, make sure to exclude Dark Reader's JavaScript files from being cached.</li>
                <li><strong>Images look strange in dark mode:</strong> Try adjusting the brightness, contrast, and grayscale settings.</li>
            </ul>
        </div>
         <div class="dark-reader-help-box">
            <h3>
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" roke-linejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                  <line x1="10" y1="9" x2="8" y2="9"/>
                </svg>
                Documentation
            </h3>
            <ul>
                <li><strong>Having trouble with Dark Reader?</strong> Check out our comprehensive troubleshooting guide to resolve common issues.</li>
                <li><a href="https://bdthemes.com/all-knowledge-base-of-dark-reader/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_Dark_Reader" target="_blank" class="dark-reader-support-btn">Knowledge Base</a></li>
            </ul>
        </div>
    </div>

    <div class="dark-reader-support">
        <h3>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0c5691" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z"></path>
                <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"></path>
            </svg>
            Need Help?
        </h3>
        <p>If you're experiencing issues or have questions about the plugin, please reach out to our support team. We're here to help!</p>
        <a href="https://wordpress.org/support/plugin/dark-reader/" target="_blank" class="dark-reader-support-btn">Contact Support</a>
    </div>
</div>

<!-- Export/Import Tab -->
<div id="dark-reader-tab-export-import" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>Export / Import Settings</h2>

        <div class="dark-reader-help-box">
            <h3>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="17 8 12 3 7 8"></polyline>
                    <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                Export Settings
            </h3>
            <p>Export your Dark Reader settings to a JSON file. This includes all appearance, toggle, advanced, and color settings<?php echo Dark_Reader::get_instance()->is_pro_active() ? ', and Pro settings if activated' : ''; ?>.</p>
            <button type="button" class="dark-reader-support-btn" id="dark-reader-export-settings">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Export Settings
            </button>
        </div>

        <div class="dark-reader-help-box">
            <h3>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2271b1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Import Settings
            </h3>
            <p>Import Dark Reader settings from a previously exported JSON file. This will overwrite your current settings.</p>
            <div class="dark-reader-import-container">
                <input type="file" id="dark-reader-import-file" accept=".json" style="display: none;">
                <button type="button" class="dark-reader-support-btn" id="dark-reader-import-settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                    </svg>
                    Import Settings
                </button>
            </div>
            <div id="dark-reader-import-status" style="margin-top: 10px;"></div>
        </div>
    </div>

    <div class="dark-reader-support">
        <h3>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0c5691" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                <line x1="12" y1="17" x2="12" y2="17"></line>
            </svg>
            Need Help?
        </h3>
        <p>Having trouble with export or import? Make sure you're using a valid JSON file exported from Dark Reader. The file should contain all your plugin settings.</p>
    </div>
</div>


<!-- License Tab -->
<div id="dark-reader-tab-license" class="dark-reader-tab-content">
    <div class="dark-reader-settings-section">
        <h2>
            Dark Reader License Management
        </h2>
        <?php
        if (class_exists('Bdthemes\DarkReaderPro\License\Form')) {
            $licenseSystem = Bdthemes\DarkReaderPro\License\Form::get_instance();
            $licenseSystem->render_license_page();
        }
        ?>
    </div>
</div>
<!-- End License Tab -->

<?php
// Include Pro tab content if Pro is active
if (Dark_Reader::get_instance()->is_pro_active()) {
    // Include analytics tab
    $analytics_tab_file = WP_PLUGIN_DIR . '/dark-reader-pro/admin/templates/analytics-tab.php';
    if (file_exists($analytics_tab_file)) {
        include_once $analytics_tab_file;
    }
    
    // Include accessibility tab
    $accessibility_tab_file = WP_PLUGIN_DIR . '/dark-reader-pro/admin/templates/accessibility-tab.php';
    if (file_exists($accessibility_tab_file)) {
        include_once $accessibility_tab_file;
    }
}
?>

<?php if (Dark_Reader::get_instance()->is_pro_active()): ?>
    <!-- Pro Custom CSS Tab -->
    <div id="dark-reader-tab-pro-custom-css" class="dark-reader-tab-content">
        <div class="dark-reader-settings-section">
            <h2>
                Custom CSS Editor
                <span class="dark-reader-pro-badge-inline">PRO</span>
            </h2>
            <p>Add custom CSS that will be applied only when dark mode is active. Perfect for fine-tuning specific elements or adding your own dark mode styles.</p>

            <div class="dark-reader-option-group">
                <label for="dark-reader-custom-css-enabled" class="dark-reader-checkbox-label">
                    <input type="checkbox" id="dark-reader-custom-css-enabled" name="dark_reader_pro_custom_css_enabled" value="1" <?php checked(get_option('dark_reader_pro_custom_css_enabled', false)); ?>>
                    <span class="dark-reader-checkbox-slider"></span>
                    Enable Custom CSS
                </label>
                <p class="dark-reader-option-description">Enable this to apply your custom CSS when dark mode is active.</p>
            </div>

            <div class="dark-reader-custom-css-editor">
                <div class="dark-reader-custom-css-controls">
                    <div class="dark-reader-css-templates">
                        <label for="dark-reader-css-template">CSS Templates:</label>
                        <select id="dark-reader-css-template">
                            <option value="">Select a template to insert...</option>
                            <?php
                            // Get CSS templates dynamically from the pro plugin
                            if (class_exists('Bdthemes\DarkReaderPro\Admin\CustomCSS')) {
                                $css_templates = Bdthemes\DarkReaderPro\Admin\CustomCSS::get_instance()->get_all_templates();
                                foreach ($css_templates as $key => $template) {
                                    echo '<option value="' . esc_attr($key) . '">' . esc_html($template['name']) . '</option>';
                                }
                            }
                            ?>
                        </select>
                        <button type="button" class="dark-reader-btn dark-reader-btn-secondary" id="dark-reader-insert-template">Insert Template</button>
                    </div>
                    <div class="dark-reader-css-actions">
                        <button type="button" class="dark-reader-btn dark-reader-btn-primary" id="dark-reader-css-beautify">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 2L2 7v10c0 5.55 3.84 10 9 10s9-4.45 9-10V7l-10-5z"></path>
                                <path d="M12 10l-3-3 1.5-1.5L12 7l1.5-1.5L15 7l-3 3"></path>
                            </svg>
                            Beautify CSS
                        </button>
                    </div>
                </div>

                <div class="dark-reader-css-editor-container">
                    <textarea id="dark-reader-custom-css" name="dark_reader_pro_custom_css" placeholder="/* Add your custom dark mode CSS here */
body.dark-reader-active {
    /* Your dark mode styles */
}

.dark-reader-active .custom-element {
    background-color: #2d2d2d;
    color: #e8e8e8;
}"><?php echo esc_textarea(get_option('dark_reader_pro_custom_css', '')); ?></textarea>
                </div>

                <div class="dark-reader-css-info">
                    <div class="dark-reader-css-stats">
                        <span>Lines: <strong id="css-line-count">0</strong></span>
                        <span>Characters: <strong id="css-char-count">0</strong></span>
                        <span>Rules: <strong id="css-rule-count">0</strong></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pro Exclusions Tab -->
    <div id="dark-reader-tab-pro-exclusions" class="dark-reader-tab-content">
        <div class="dark-reader-settings-section">
            <h2>
                Element Exclusions
                <span class="dark-reader-pro-badge-inline">PRO</span>
            </h2>
            <p>Exclude specific elements from dark mode transformation. Useful for logos, images, videos or elements that should maintain their original appearance.</p>

            <div class="dark-reader-exclusions-container">
                <div class="dark-reader-exclusion-type-tabs">
                    <button type="button" class="dark-reader-exclusion-tab active" data-type="selectors">CSS Selectors</button>
                    <button type="button" class="dark-reader-exclusion-tab" data-type="images">Images</button>
                    <button type="button" class="dark-reader-exclusion-tab" data-type="videos">Videos</button>
                </div>

                <!-- CSS Selectors Exclusion -->
                <div class="dark-reader-exclusion-content active" data-type="selectors">
                    <table class="dark-reader-form-table">
                        <tr>
                            <th>CSS Selectors</th>
                            <td>
                                <textarea name="dark_reader_pro_exclude_selectors" rows="8" placeholder=".logo
#header-image
.brand-colors
.custom-widget"><?php echo esc_textarea(get_option('dark_reader_pro_exclude_selectors', '')); ?></textarea>
                                <span class="description">Enter CSS selectors (one per line) to exclude from dark mode. Examples: .logo, #header, .brand-element</span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Images Exclusion -->
                <div class="dark-reader-exclusion-content" data-type="images">
                    <table class="dark-reader-form-table">
                        <tr>
                            <th>Image Exclusions</th>
                            <td>
                                <label class="dark-reader-toggle-switch">
                                    <input type="checkbox" name="dark_reader_pro_exclude_all_images" value="1" <?php checked(get_option('dark_reader_pro_exclude_all_images'), '1'); ?>>
                                    <span class="dark-reader-toggle-slider"></span>
                                </label>
                                <span class="description">Exclude all images from dark mode transformation</span>
                            </td>
                        </tr>
                        <tr class="dark-reader-logo-selectors-row" style="<?php echo get_option('dark_reader_pro_exclude_all_images', false) ? 'display: none;' : ''; ?>">
                            <th>Exclude Specific Images</th>
                            <td>
                                <input type="text" name="dark_reader_pro_logo_selectors" value="<?php echo esc_attr(get_option('dark_reader_pro_logo_selectors', '')); ?>" placeholder=".logo, .site-logo, #logo" class="regular-text">
                                <span class="description">CSS selectors for excluding specific images from dark mode transformation (comma separated)</span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Videos Exclusion -->
                <div class="dark-reader-exclusion-content" data-type="videos">
                    <table class="dark-reader-form-table">
                        <tr>
                            <th>Video Exclusions</th>
                            <td>
                                <label class="dark-reader-toggle-switch">
                                    <input type="checkbox" name="dark_reader_pro_exclude_videos" value="1" <?php checked(get_option('dark_reader_pro_exclude_videos'), '1'); ?>>
                                    <span class="dark-reader-toggle-slider"></span>
                                </label>
                                <span class="description">Exclude all videos from dark mode transformation</span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Pro Schedule Tab -->
    <div id="dark-reader-tab-pro-schedule" class="dark-reader-tab-content">
        <div class="dark-reader-settings-section">
            <h2>
                Smart Scheduling
                <span class="dark-reader-pro-badge-inline">PRO</span>
            </h2>
            <p>Automatically enable dark mode based on time, date, or user's system preferences.</p>

            <table class="dark-reader-form-table">
                <tr>
                    <th>Enable Scheduling</th>
                    <td>
                        <label class="dark-reader-toggle-switch">
                            <input type="checkbox" id="schedule-enabled-toggle" name="dark_reader_pro_schedule_enabled" value="1" <?php checked(get_option('dark_reader_pro_schedule_enabled'), '1'); ?>>
                            <span class="dark-reader-toggle-slider"></span>
                        </label>
                        <span class="description">Enable automatic dark mode scheduling</span>
                    </td>
                </tr>
                <tr class="dark-reader-scheduler-dependent <?php echo get_option('dark_reader_pro_schedule_enabled') ? 'enabled' : 'disabled'; ?>">
                    <th>Schedule Type</th>
                    <td>
                        <select name="dark_reader_pro_schedule_type">
                            <option value="time" <?php selected(get_option('dark_reader_pro_schedule_type'), 'time'); ?>>Time Based</option>
                            <option value="system" <?php selected(get_option('dark_reader_pro_schedule_type'), 'system'); ?>>System Preference</option>
                            <option value="sunset" <?php selected(get_option('dark_reader_pro_schedule_type'), 'sunset'); ?>>Sunset/Sunrise</option>
                        </select>
                        <span class="description">Choose how dark mode should be scheduled</span>
                    </td>
                </tr>
                <tr class="schedule-time-controls dark-reader-scheduler-time-dependent <?php echo (get_option('dark_reader_pro_schedule_type') === 'time') ? 'enabled' : 'disabled'; ?>">
                    <th>Start Time</th>
                    <td>
                        <input type="time" name="dark_reader_pro_schedule_start_time" value="<?php echo esc_attr(get_option('dark_reader_pro_schedule_start_time', '18:00')); ?>">
                        <span class="description">Time to automatically enable dark mode</span>
                    </td>
                </tr>
                <tr class="schedule-time-controls dark-reader-scheduler-time-dependent <?php echo (get_option('dark_reader_pro_schedule_type') === 'time') ? 'enabled' : 'disabled'; ?>">
                    <th>End Time</th>
                    <td>
                        <input type="time" name="dark_reader_pro_schedule_end_time" value="<?php echo esc_attr(get_option('dark_reader_pro_schedule_end_time', '06:00')); ?>">
                        <span class="description">Time to automatically disable dark mode</span>
                    </td>
                </tr>
                <tr class="schedule-info-row dark-reader-scheduler-dependent <?php echo get_option('dark_reader_pro_schedule_enabled') ? 'enabled' : 'disabled'; ?>">
                    <td colspan="2">
                        <div class="schedule-info-message">
                            <p><strong>System Preference:</strong> Dark mode will automatically follow your operating system's dark mode setting.</p>
                            <p><strong>Sunset/Sunrise:</strong> Dark mode will automatically activate based on real sunset and sunrise times for your location.</p>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Pro Page Visibility Tab -->
    <div id="dark-reader-tab-pro-page-visibility" class="dark-reader-tab-content">
        <div class="dark-reader-settings-section">
            <h2>
                Page Visibility Controls
                <span class="dark-reader-pro-badge-inline">PRO</span>
            </h2>
            <p>Control where the dark mode should be applied with toggle buttons. Hide or show the toggle on specific pages, posts, or page types.</p>

            <table class="dark-reader-form-table">
                <tr>
                    <th>Visibility Mode</th>
                    <td>
                        <select name="dark_reader_pro_page_visibility_mode">
                            <option value="show_all" <?php selected($pro_page_visibility_mode ?? 'show_all', 'show_all'); ?>>Show on all pages</option>
                            <option value="show_selected" <?php selected($pro_page_visibility_mode ?? 'show_all', 'show_selected'); ?>>Show only on selected pages</option>
                            <option value="hide_selected" <?php selected($pro_page_visibility_mode ?? 'show_all', 'hide_selected'); ?>>Hide on selected pages</option>
                            <option value="hide_all" <?php selected($pro_page_visibility_mode ?? 'show_all', 'hide_all'); ?>>Hide on all pages</option>
                        </select>
                        <span class="description">Choose how to control toggle button visibility</span>
                    </td>
                </tr>
                <tr class="page-type-controls dark-reader-page-visibility-dependent <?php echo (($pro_page_visibility_mode ?? 'show_all') === 'show_all' || ($pro_page_visibility_mode ?? 'show_all') === 'hide_all') ? 'disabled' : 'enabled'; ?>">
                    <th>Page Types</th>
                    <td>
                        <fieldset>
                            <label><input type="checkbox" name="dark_reader_pro_show_on_front_page" value="1" <?php checked($pro_show_on_front_page ?? true); ?>> Front Page</label><br>
                            <label><input type="checkbox" name="dark_reader_pro_show_on_blog" value="1" <?php checked($pro_show_on_blog ?? true); ?>> Blog Page</label><br>
                            <label><input type="checkbox" name="dark_reader_pro_show_on_posts" value="1" <?php checked($pro_show_on_posts ?? true); ?>> Single Posts</label><br>
                            <label><input type="checkbox" name="dark_reader_pro_show_on_pages" value="1" <?php checked($pro_show_on_pages ?? true); ?>> Pages</label><br>
                            <label><input type="checkbox" name="dark_reader_pro_show_on_archive" value="1" <?php checked($pro_show_on_archive ?? true); ?>> Archive Pages</label>
                        </fieldset>
                        <span class="description">Select which page types should show the toggle button</span>
                    </td>
                </tr>
                <tr class="dark-reader-page-visibility-dependent <?php echo (($pro_page_visibility_mode ?? 'show_all') === 'show_all' || ($pro_page_visibility_mode ?? 'show_all') === 'hide_all') ? 'disabled' : 'enabled'; ?>">
                    <th>Specific Pages</th>
                    <td>
                        <textarea name="dark_reader_pro_page_ids" rows="4" placeholder="123, 456, 789"><?php echo esc_textarea($pro_page_ids ?? ''); ?></textarea>
                        <span class="description">Enter page/post IDs (comma separated) for specific visibility control</span>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Pro Admin Dark Mode Tab -->
    <div id="dark-reader-tab-pro-admin" class="dark-reader-tab-content">
        <div class="dark-reader-settings-section">
            <h2>
                WordPress Admin Dark Mode
                <span class="dark-reader-pro-badge-inline">PRO</span>
            </h2>
            <p>Enable dark mode for the WordPress admin dashboard. Customize the admin experience with dark themes and adjustable settings.</p>

            <table class="dark-reader-form-table">
                <tr>
                    <th>Enable Admin Dark Mode</th>
                    <td>
                        <label class="dark-reader-toggle-switch">
                            <input type="checkbox" id="admin-dark-mode-toggle" name="dark_reader_pro_admin_dark_mode" value="1" <?php checked(get_option('dark_reader_pro_admin_dark_mode'), '1'); ?>>
                            <span class="dark-reader-toggle-slider"></span>
                        </label>
                        <span class="description">Apply dark mode to WordPress admin dashboard</span>
                    </td>
                </tr>
                <tr class="dark-reader-admin-dependent <?php echo get_option('dark_reader_pro_admin_dark_mode') ? 'enabled' : 'disabled'; ?>" id="admin-brightness-row">
                    <th>Admin Brightness</th>
                    <td>
                        <div class="dark-reader-slider-container">
                            <input type="range" id="admin-brightness" name="dark_reader_pro_admin_brightness"
                                min="50" max="150" value="<?php echo esc_attr(get_option('dark_reader_pro_admin_brightness', '100')); ?>"
                                class="dark-reader-slider">
                            <span id="admin-brightness-value"><?php echo esc_html(get_option('dark_reader_pro_admin_brightness', '100')); ?>%</span>
                        </div>
                        <span class="description">Adjust admin interface brightness (50% - 150%)</span>
                    </td>
                </tr>
                <tr class="dark-reader-admin-dependent <?php echo get_option('dark_reader_pro_admin_dark_mode') ? 'enabled' : 'disabled'; ?>" id="admin-contrast-row">
                    <th>Admin Contrast</th>
                    <td>
                        <div class="dark-reader-slider-container">
                            <input type="range" id="admin-contrast" name="dark_reader_pro_admin_contrast"
                                min="50" max="150" value="<?php echo esc_attr(get_option('dark_reader_pro_admin_contrast', '90')); ?>"
                                class="dark-reader-slider">
                            <span id="admin-contrast-value"><?php echo esc_html(get_option('dark_reader_pro_admin_contrast', '90')); ?>%</span>
                        </div>
                        <span class="description">Adjust admin interface contrast (50% - 150%)</span>
                    </td>
                </tr>
                <tr class="dark-reader-admin-dependent <?php echo get_option('dark_reader_pro_admin_dark_mode') ? 'enabled' : 'disabled'; ?>" id="admin-auto-detect-row">
                    <th>Auto-detect User Preference</th>
                    <td>
                        <label class="dark-reader-toggle-switch">
                            <input type="checkbox" name="dark_reader_pro_admin_auto_detect" value="1" <?php checked(get_option('dark_reader_pro_admin_auto_detect'), '1'); ?>>
                            <span class="dark-reader-toggle-slider"></span>
                        </label>
                        <span class="description">Automatically enable admin dark mode based on user's system preference</span>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Include Custom Toggle Button Editor Modal -->
    <?php
    $custom_toggle_template = plugin_dir_path(dirname(dirname(__FILE__))) . '../dark-reader-pro/admin/templates/custom-toggle-editor.php';
    if (file_exists($custom_toggle_template) && Dark_Reader::get_instance()->has_valid_pro_license()) {
        include($custom_toggle_template);
    }
    ?>
<?php endif; ?>