<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Enqueue service class.
 *
 * @package Dark_Mode_Toggle
 */

namespace DarkModeToggle;

defined( 'ABSPATH' ) || die();

/**
 * Register and enqueue front styles and scripts.
 */
class Enqueue extends Base implements Service {
	/**
	 * Initialize service.
	 */
	public function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_head', array( $this, 'admin_hide_darkmode_elements' ) );
	}

	/**
	 * Ẩn các element darkmode-js bị inject bởi plugin khác trong trang wp-admin.
	 */
	public function admin_hide_darkmode_elements() {
		echo '<style>.darkmode-toggle,.darkmode-layer,.darkmode-background{display:none!important;width:0!important;height:0!important;overflow:hidden!important;opacity:0!important;pointer-events:none!important}</style>' . "\n";
	}

	/**
	 * Enqueue styles and scripts.
	 */
	public function enqueue() {
		$front = darkmodetg( 'options' )->get_main( 'front' );

		if ( $front['enable'] && ! is_customize_preview() ) {
			darkmodetg( 'utility' )->enqueue( $front );
		}
	}
}
