<?php

/**
 * Admin Page Template for Dark Reader
 *
 * @package Dark Reader
 * @since 1.1.6
 */

// Exit if accessed directly
if (!defined('WPINC')) {
    die('Direct access not permitted.');
}

// Extract settings array to make variables accessible
extract($settings);
?>
<div class="dark-reader-admin-wrapper">
    <!-- Header -->
    <div class="dark-reader-header">
        <div class="dark-reader-header-shape"></div>
        <div class="dark-reader-header-content">
            <h1>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
                </svg>
                Dark Reader
                <span class="dark-reader-version">v<?php echo esc_html($version); ?></span>
            </h1>
            <p>Add beautiful dark mode to your WordPress site with advanced customization options and multiple toggle styles.</p>
        </div>
        <div class="dark-reader-widget-info-icon">
            <a href="#dark-reader-tab-help" class="dark-reader-nav-tab dark-reader-help-btn" title="How to Use the Shortcode">
                <span class="dark-help-btn-text">Help & Support</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                    <line x1="12" y1="17" x2="12" y2="17"></line>
                </svg>
            </a>
        </div>
    </div>

    <div class="dark-reader-content">
        <!-- Sidebar Navigation -->
        <div class="dark-reader-sidebar-nav">
            <div class="dark-reader-nav-section">
                <h3>General Settings</h3>
                <a href="#dark-reader-tab-appearance" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-appearance') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 20.25c4.55 0 8.25-3.7 8.25-8.25S16.55 3.75 12 3.75 3.75 7.45 3.75 12s3.7 8.25 8.25 8.25z"></path>
                        <path d="M12 8.25v3.75L15 15"></path>
                    </svg>
                    Appearance
                </a>
                <a href="#dark-reader-tab-toggle" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-toggle') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect width="20" height="12" x="2" y="6" rx="2"></rect>
                        <circle cx="16" cy="12" r="2"></circle>
                    </svg>
                    Toggle Button
                </a>
                <a href="#dark-reader-tab-advanced" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-advanced') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                    Advanced
                </a>
                <a href="#dark-reader-tab-colors" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-colors') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                    </svg>
                    Colors
                </a>
            </div>

            <?php if (Dark_Reader::get_instance()->is_pro_active()): ?>
                <div class="dark-reader-nav-section">
                    <h3>Pro Features</h3>
                    <a href="#dark-reader-tab-pro-custom-css" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-custom-css') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M16 18l6-6-6-6"></path>
                            <path d="M8 6l-6 6 6 6"></path>
                        </svg>
                        Custom CSS
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-exclusions" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-exclusions') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 6L6 18"></path>
                            <path d="M6 6l12 12"></path>
                        </svg>
                        Exclusions
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-schedule" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-schedule') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12,6 12,12 16,14"></polyline>
                        </svg>
                        Schedule
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-page-visibility" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-page-visibility') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                        Page Visibility
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-admin" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-admin') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 20.25c4.55 0 8.25-3.7 8.25-8.25S16.55 3.75 12 3.75 3.75 7.45 3.75 12s3.7 8.25 8.25 8.25z"></path>
                            <path d="M12 8.25v3.75L15 15"></path>
                        </svg>
                        Admin Dark Mode
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-analytics" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-analytics') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 3v18h18"></path>
                            <path d="M18 17V9"></path>
                            <path d="M13 17V5"></path>
                            <path d="M8 17v-3"></path>
                        </svg>
                        Dark Mode Analytics
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                    <a href="#dark-reader-tab-pro-accessibility" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-pro-accessibility') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M12 16v-4"></path>
                            <circle cx="12" cy="8" r="0.5"></circle>
                        </svg>
                        Accessibility
                        <?php if (!Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                            <div class="dark-reader-pro-lock-badge">
                              <span class="dark-reader-pro-badge-inline">PRO</span>
                            </div>
                        <?php endif; ?>
                    </a>
                </div>
            <?php endif; ?>

            <div class="dark-reader-nav-section">
                <h3>Support</h3>
                <a href="#dark-reader-tab-help" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-help') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                        <line x1="12" y1="17" x2="12" y2="17"></line>
                    </svg>
                    Help & Support
                </a>
                <a href="#dark-reader-tab-export-import" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-export-import') ? 'dark-reader-nav-tab-active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                    Export / Import
                </a>
            </div>
            <?php if (Dark_Reader::get_instance()->is_pro_active()): ?>
                <div class="dark-reader-nav-section">
                    <h3>License</h3>
                    <a href="#dark-reader-tab-license" class="dark-reader-nav-tab <?php echo (isset($active_tab) && $active_tab === 'dark-reader-tab-license') ? 'dark-reader-nav-tab-active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 20.25c4.55 0 8.25-3.7 8.25-8.25S16.55 3.75 12 3.75 3.75 7.45 3.75 12s3.7 8.25 8.25 8.25z"></path>
                            <path d="M12 8.25v3.75L15 15"></path>
                        </svg>
                        License
                    </a>
                </div>
            <?php endif; ?>
            <!-- Pro Status -->
            <?php if (!Dark_Reader::get_instance()->is_pro_active()): ?>
                <div class="dark-reader-pro-features">
                    <div class="dark-reader-pro-badge">Available Now!</div>
                    <h3>Dark Reader Pro</h3>
                    <p>Unlock advanced features:</p>
                    <ul>
                        <li>6+ toggle button styles</li>
                        <li>Customize toggle button styles</li>
                        <li>Custom CSS editor</li>
                        <li>Element exclusions</li>
                        <li>Smart scheduling</li>
                        <li>Page visibility controls</li>
                        <li>Admin dark mode</li>
                        <li>Image replacement</li>
                        <li>Widget Support</li>
                        <li>Dark Reader Analytics</li>
                        <li>Accessibility options</li>
                    </ul>
                    <a href="https://bdthemes.com/plugin/dark-reader/?utm_source=WordPress_Repository&utm_medium=Plugin_Page&utm_campaign=WordPress_to_Dark_Reader#pricing" target="_blank" class="dark-reader-pro-btn">Get PRO Version</a>      
                </div>
            <?php else: ?>
                <?php if (Dark_Reader::get_instance()->is_pro_active() && Dark_Reader::get_instance()->has_valid_pro_license()): ?>
                    <div class="dark-reader-pro-activated">
                        <div class="dark-reader-pro-badge-active">Pro Activated!</div>
                        <h3>Dark Reader Pro</h3>
                        <p>✨ All premium features unlocked!</p>
                    </div>
                <?php else: ?>
                    <div class="dark-reader-license-activated">
                        <div class="dark-reader-pro-badge-active">License Required!</div>
                        <h3>Dark Reader Pro</h3>
                        <p>✨ All premium features will be unlocked after activating license!</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="dark-reader-main">
            <!-- Settings Form (excludes license tab) -->
            <form method="post" id="dark-reader-settings-form" class="dark-reader-settings-form">
                <?php
                wp_nonce_field('dark_reader_settings_nonce', 'dark_reader_nonce');
                ?>
                <?php
                // Include all tabs except license tab
                ob_start();
                include(Dark_Reader::get_instance()->get_plugin_dir() . 'admin/templates/tabs-content.php');
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not a global
                $content = ob_get_clean();

                // Remove license tab content from the form
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not a global
                $content = preg_replace('/<!-- License Tab -->.*?<!-- End License Tab -->/s', '', $content);
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted internal template, all dynamic content already escaped
                echo $content;
                ?>
                <button type="submit" class="dark-reader-submit-btn" id="dark-reader-save-btn">Save Settings</button>
            </form>

            <!-- License Tab Content (outside the form) -->
            <?php
            // Extract and display only the license tab content
            ob_start();
            include(Dark_Reader::get_instance()->get_plugin_dir() . 'admin/templates/tabs-content.php');
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Local template variable, not a global
            $all_content = ob_get_clean();

            if (preg_match('/<!-- License Tab -->(.*?)<!-- End License Tab -->/s', $all_content, $matches)) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted internal template, all dynamic content already escaped
                echo $matches[1];
            }
            ?>
        </div>
    </div>

    <div class="dark-reader-footer">
        Dark Reader for WordPress v<?php echo esc_html($version); ?> | Made with ❤️ by <a href="https://bdthemes.com/" target="_blank">BdThemes</a>
    </div>
</div>