<?php

declare(strict_types=1);

/**
 * Dark Reader Toggle Button Class
 *
 * Handles rendering and initialization of the dark mode toggle button.
 *
 * @package Dark_Reader
 * @since 1.1.6
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die(esc_html__('Direct access not permitted.', 'dark-reader'));
}

/**
 * Class to handle the dark mode toggle button functionality
 */
class Dark_Reader_Toggle
{

    /**
     * Initialize the toggle button
     *
     * @return void
     */
    public function init(): void
    {
        add_action('wp_footer', [$this, 'render_toggle_button']);
    }

    /**
     * Render the toggle button in the footer
     *
     * @return void
     */
    public function render_toggle_button(): void
    {
        // Check if toggle should be shown (allows pro version to control visibility)
        if (!Dark_Reader::get_instance()->should_show_toggle()) {
            return;
        }

        $position = get_option('dark_reader_toggle_position', 'bottom-right');
        $style = get_option('dark_reader_toggle_style', 'default');

        // Pro styles fallback: if pro is not active or license is invalid, use default style
        $pro_styles = ['modern-slider', 'text-toggle', 'flipflop-toggle', 'ios-toggle', 'ios-toggle-icon', 'liquid-glass', 'custom'];
        if (in_array($style, $pro_styles)) {
            if (!Dark_Reader::get_instance()->is_pro_active() || !Dark_Reader::get_instance()->has_valid_pro_license()) {
                $style = 'default';
                update_option('dark_reader_toggle_style', 'default');
            }
        }
        ?>
        <div id="dark-reader-toggle"
            class="dark-reader-toggle <?php echo esc_attr($position); ?> style-<?php echo esc_attr($style); ?>">
            <button aria-label="<?php echo esc_attr__('Toggle Dark Mode', 'dark-reader'); ?>">
                <?php $this->render_toggle_style($style); ?>
            </button>
        </div>
        <?php
    }

    /**
     * Render the specific toggle style
     *
     * @param string $style The toggle button style
     * @return void
     */
    private function render_toggle_style(string $style): void
    {
        switch ($style) {
            case 'default':
            case 'round':
                $this->render_default_style();
                break;
            case 'switch':
                $this->render_switch_style();
                break;
            case 'toggle':
                $this->render_toggle_style_icons();
                break;
            case 'minimal':
                $this->render_minimal_style();
                break;
            // case 'slider':
            //     $this->render_slider_style();
            //     break;
            case 'text-toggle':
                $this->render_text_toggle_style();
                break;
            case 'flipflop-toggle':
                $this->render_flipflop_toggle_style();
                break;
            case 'ios-toggle':
                $this->render_ios_toggle_style();
                break;
            case 'ios-toggle-icon':
                $this->render_ios_toggle_icon_style();
                break;
            case 'liquid-glass':
                $this->render_liquid_glass_style();
                break;
            case 'custom':
                $this->render_custom_style();
                break;
        }
    }

    /**
     * Render default/round style
     *
     * @return void
     */
    private function render_default_style(): void
    {
        echo '<span class="sun-icon">☀️</span>';
        echo '<span class="moon-icon">🌙</span>';
    }

    /**
     * Render switch style
     *
     * @return void
     */
    private function render_switch_style(): void
    {
        echo '<span class="switch-track"></span>';
        echo '<span class="switch-thumb"></span>';
    }

    /**
     * Render toggle style with icons
     *
     * @return void
     */
    private function render_toggle_style_icons(): void
    {
        ?>
        <span class="toggle-track">
            <span class="toggle-sun">☀️</span>
            <span class="toggle-moon">🌙</span>
        </span>
        <span class="toggle-thumb"></span>
        <?php
    }

    /**
     * Render minimal style
     *
     * @return void
     */
    private function render_minimal_style(): void
    {
        echo '<span class="minimal-icon"></span>';
    }

    /**
     * Render slider style
     *
     * @return void
     */
    // private function render_slider_style(): void
    // {
    //     <span class="slider-container">
    //         <span class="slider-background"></span>
    //         <span class="slider-track">
    //             <span class="slider-icon sun">☀️</span>
    //             <span class="slider-icon moon">🌙</span>
    //         </span>
    //         <span class="slider-thumb"></span>
    //     </span>
    // }

    /**
     * Render text toggle style with Light/Dark labels
     *
     * @return void
     */
    private function render_text_toggle_style(): void
    {
        echo '<span class="text-label light">Light</span>';
        echo '<span class="text-label dark">Dark</span>';
    }

    /**
     * Render flipflop toggle style
     *
     * @return void
     */
    private function render_flipflop_toggle_style(): void
    {
        echo '<span class="flipflop-track"></span>';
        echo '<span class="flipflop-thumb"></span>';
    }

    /**
     * Render iOS toggle style
     *
     * @return void
     */
    private function render_ios_toggle_style(): void
    {
        ?>
        <div class="ios-toggle-track">
            <span class="ios-toggle-text off">Light</span>
            <span class="ios-toggle-text on">Dark</span>
        </div>
        <?php
    }

    /**
     * Render iOS toggle style with icons
     *
     * @return void
     */
    private function render_ios_toggle_icon_style(): void
    {
        ?>
        <div class="ios-toggle-track">
            <span class="ios-toggle-text off">☀️</span>
            <span class="ios-toggle-text on">🌙</span>
        </div>
        <?php
    }

    /**
     * Render liquid glass style
     *
     * @return void
     */
    private function render_liquid_glass_style(): void
    {
        // Liquid glass style uses CSS pseudo-elements for the track and thumb
        // No additional HTML markup is needed
        ?>
        <div class="liquid-glass-icons">
            <span class="glass-icon off">🌙</span>
            <span class="glass-icon on">☀️</span>
        </div>
        <?php
    }


    /**
     * Render custom style with user-defined settings
     *
     * @return void
     */
    private function render_custom_style(): void
    {
        $light_icon = get_option('dark_reader_pro_custom_light_icon', '☀️');
        $dark_icon = get_option('dark_reader_pro_custom_dark_icon', '🌙');
        
        // Fallback to defaults if empty
        if (empty($light_icon)) {
            $light_icon = '☀️';
        }
        if (empty($dark_icon)) {
            $dark_icon = '🌙';
        }
        
        echo '<span class="custom-icon light-icon">' . esc_html($light_icon) . '</span>';
        echo '<span class="custom-icon dark-icon">' . esc_html($dark_icon) . '</span>';
    }

}

// Initialize the toggle button
$dark_reader_toggle = new Dark_Reader_Toggle();
$dark_reader_toggle->init();
