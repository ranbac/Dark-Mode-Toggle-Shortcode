<?php

declare(strict_types=1);

/**
 * Class to handle script and style enqueuing for Dark Reader.
 *
 * @package Dark Reader
 * @since 1.1.6
 */

// Exit if accessed directly
if (!defined('WPINC')) {
    die(esc_html__('Direct access not permitted.', 'dark-reader'));
}

/**
 * Dark_Reader_Enqueue Class
 */
class Dark_Reader_Enqueue {

    /**
     * Instance of this class.
     *
     * @since 1.1.6
     * @var self|null
     */
    private static ?self $instance = null;

    /**
     * Initialize the class and set its properties.
     *
     * @since 1.1.6
     */
    private function __construct() {
        $this->setup_hooks();
    }

    /**
     * Return an instance of this class.
     *
     * @since 1.1.6
     * @return self A single instance of this class.
     */
    public static function get_instance(): self {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Set up WordPress hooks and filters.
     *
     * @since 1.1.6
     * @return void
     */
    private function setup_hooks(): void {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Enqueue scripts and styles.
     *
     * @since 1.1.6
     * @return void
     */
    public function enqueue_scripts(): void {
        // Add critical inline CSS to prevent FOUC
        $this->add_critical_inline_css();

        // Enqueue Dark Reader script in head for immediate execution
        wp_enqueue_script(
            'darkreader',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/js/vendor/' . (defined('WP_DEBUG') && WP_DEBUG ? 'darkreader.js' : 'darkreader.min.js'),
            [],
            Dark_Reader::get_instance()->get_version(),
            false // Load in head, not footer
        );

        // Enqueue our custom script in head
        wp_enqueue_script(
            'dark-reader-init',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/js/dark-reader-init.js',
            ['darkreader'],
            Dark_Reader::get_instance()->get_version(),
            false // Load in head, not footer
        );

        // Enqueue styles for the toggle button
        wp_enqueue_style(
            'dark-reader-toggle',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/css/dark-reader-toggle.css',
            [],
            Dark_Reader::get_instance()->get_version()
        );

        // Prepare settings data
        $settings = [
                'brightness' => get_option('dark_reader_brightness', 100),
                'contrast' => get_option('dark_reader_contrast', 90),
                'sepia' => get_option('dark_reader_sepia', 10),
                'grayscale' => get_option('dark_reader_grayscale', 0),
                'textStroke' => floatval(get_option('dark_reader_text_stroke', 0)),
                'mode' => intval(get_option('dark_reader_filter_mode', 1)),
                'useSystemColorScheme' => get_option('dark_reader_use_system_color_scheme', false),
                'enableForPDFs' => get_option('dark_reader_enable_for_pdfs', false),
                'darkSchemeBackgroundColor' => get_option('dark_reader_dark_scheme_background', ''),
                'darkSchemeTextColor' => get_option('dark_reader_dark_scheme_text', ''),
                'immediateModify' => get_option('dark_reader_immediate_modify', true),
                'defaultDarkMode' => get_option('dark_reader_default_dark_mode', false),
                'toggleBtnPosition' => get_option('dark_reader_toggle_position', 'bottom-right'),
                'toggleBtnStyle' => get_option('dark_reader_toggle_style', 'default'),
                'isProActive' => Dark_Reader::get_instance()->is_pro_active(),
                'shouldApplyDarkMode' => apply_filters('dark_reader_should_apply_dark_mode', true)
        ];
        
        // Allow pro version to add additional settings
        $settings = apply_filters('dark_reader_frontend_settings', $settings);

        // Pass data to our script
        wp_localize_script(
            'dark-reader-init',
            'darkReaderSettings',
            $settings
        );
    }

    /**
     * Add critical inline CSS to prevent FOUC
     *
     * @since 1.1.6
     * @return void
     */
    private function add_critical_inline_css(): void {
        // Check if dark mode should be enabled by default or system color scheme
        $default_dark_mode = get_option('dark_reader_default_dark_mode', false);
        $use_system_color_scheme = get_option('dark_reader_use_system_color_scheme', false);
        
        if (!$default_dark_mode && !$use_system_color_scheme) {
            return;
        }

        // Add critical CSS inline to prevent flash
        $critical_css = '
        <style id="dark-reader-critical-fallback">
            html.dark-reader-critical-loading {
                filter: invert(1) hue-rotate(180deg) !important;
                transition: filter 0.1s ease !important;
            }
            html.dark-reader-critical-loading img,
            html.dark-reader-critical-loading video,
            html.dark-reader-critical-loading iframe,
            html.dark-reader-critical-loading svg,
            html.dark-reader-critical-loading [style*="background-image"],
            html.dark-reader-critical-loading canvas,
            html.dark-reader-critical-loading embed,
            html.dark-reader-critical-loading object {
                filter: invert(1) hue-rotate(180deg) !important;
            }
        </style>
        <script>
            (function() {
                try {
                    var pageVisibilityMode = "' . get_option('dark_reader_pro_page_visibility_mode', 'show_all') . '";
                    var currentPageId = "default";
                    var defaultDark = ' . ($default_dark_mode ? 'true' : 'false') . ';
                    var useSystemColorScheme = ' . ($use_system_color_scheme ? 'true' : 'false') . ';
                    var shouldApplyOnThisPage = ' . (apply_filters('dark_reader_should_apply_dark_mode', true) ? 'true' : 'false') . ';
                    
                    var shouldApply = false;
                    
                    // Clean up localStorage if mode changed
                    var currentModeStored = localStorage.getItem("darkReaderVisibilityMode");
                    if (currentModeStored && currentModeStored !== pageVisibilityMode) {
                        if (pageVisibilityMode === "show_all" || pageVisibilityMode === "hide_all") {
                            // Switching to global mode - remove page-specific entries
                            Object.keys(localStorage).forEach(function(key) {
                                if (key.indexOf("darkReaderEnabled_") === 0) {
                                    localStorage.removeItem(key);
                                }
                            });
                        } else {
                            // Switching to page-specific mode - remove global entry
                            localStorage.removeItem("darkReaderEnabled");
                        }
                    }
                    localStorage.setItem("darkReaderVisibilityMode", pageVisibilityMode);
                    
                    // Check if user has manually toggled (takes precedence)
                    var manualToggle = localStorage.getItem("darkReaderManualToggle");
                    if (manualToggle === "true") {
                        // Get preference based on visibility mode
                        if (pageVisibilityMode === "show_all" || pageVisibilityMode === "hide_all") {
                            var stored = localStorage.getItem("darkReaderEnabled");
                            shouldApply = stored ? stored === "1" : defaultDark;
                        } else {
                            var pageSpecificKey = "darkReaderEnabled_" + currentPageId;
                            var stored = localStorage.getItem(pageSpecificKey);
                            shouldApply = stored ? stored === "1" : defaultDark;
                        }
                    }
                    // Check system color scheme if enabled and no manual toggle
                    else if (useSystemColorScheme && window.matchMedia) {
                        if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
                            shouldApply = true;
                        } else if (window.matchMedia("(prefers-color-scheme: light)").matches) {
                            shouldApply = false;
                        } else {
                            // Fallback to stored preference or default
                            if (pageVisibilityMode === "show_all" || pageVisibilityMode === "hide_all") {
                                var stored = localStorage.getItem("darkReaderEnabled");
                                shouldApply = stored ? stored === "1" : defaultDark;
                            } else {
                                var pageSpecificKey = "darkReaderEnabled_" + currentPageId;
                                var stored = localStorage.getItem(pageSpecificKey);
                                shouldApply = stored ? stored === "1" : defaultDark;
                            }
                        }
                    }
                    // Fall back to stored preference or default
                    else {
                        if (pageVisibilityMode === "show_all" || pageVisibilityMode === "hide_all") {
                            var stored = localStorage.getItem("darkReaderEnabled");
                            shouldApply = stored ? stored === "1" : defaultDark;
                        } else {
                            var pageSpecificKey = "darkReaderEnabled_" + currentPageId;
                            var stored = localStorage.getItem(pageSpecificKey);
                            shouldApply = stored ? stored === "1" : defaultDark;
                        }
                    }
                    
                    if (shouldApply && shouldApplyOnThisPage) {
                        document.documentElement.classList.add("dark-reader-critical-loading");
                    }
                } catch (e) {
                    // Fallback: check system preference directly or use default
                    var shouldFallback = false;
                    if (' . ($use_system_color_scheme ? 'true' : 'false') . ' && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
                        shouldFallback = true;
                    } else if (' . ($default_dark_mode ? 'true' : 'false') . ') {
                        shouldFallback = true;
                    }
                    
                    if (shouldFallback && ' . (apply_filters('dark_reader_should_apply_dark_mode', true) ? 'true' : 'false') . ') {
                        document.documentElement.classList.add("dark-reader-critical-loading");
                    }
                }
            })();
        </script>';

        // Output critical CSS in head
        add_action('wp_head', function() use ($critical_css) {
            // echo $critical_css;
            echo '<style>' . esc_html( $critical_css ) . '</style>';
        }, 1);
    }
}

// Initialize the scripts class
Dark_Reader_Enqueue::get_instance();
