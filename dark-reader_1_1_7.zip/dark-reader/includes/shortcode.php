<?php

declare(strict_types=1);

/**
 * Shortcode functionality for Dark Reader
 *
 * @package Dark Reader
 * @since 1.1.6
 */

// Exit if accessed directly
if (!defined('WPINC')) {
    die(esc_html__('Direct access not permitted.', 'dark-reader'));
}

/**
 * Dark Reader Toggle Shortcode class
 */
class Dark_Reader_Toggle_Shortcode
{

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->register_shortcode();
    }

    /**
     * Register the shortcode
     */
    private function register_shortcode(): void
    {
        add_shortcode('dark_reader_toggle', [$this, 'render_toggle_button']);
    }

    /**
     * Render the toggle button
     *
     * @return string HTML output for toggle button
     */
    public function render_toggle_button(): string
    {
        ob_start();
        $style = get_option('dark_reader_toggle_style', 'default');

        // Pro styles fallback: if pro is not active or license is invalid, use default style
        $pro_styles = ['modern-slider', 'text-toggle', 'flipflop-toggle', 'ios-toggle', 'ios-toggle-icon', 'liquid-glass', 'custom'];
        if (in_array($style, $pro_styles)) {
            if (!Dark_Reader::get_instance()->is_pro_active() || !Dark_Reader::get_instance()->has_valid_pro_license()) {
                $style = 'default';
            }
        }
        ?>
        <div class="dark-reader-toggle-inline style-<?php echo esc_attr($style); ?>">
            <button id="dark-reader-toggle-inline" aria-label="<?php echo esc_attr__('Toggle Dark Mode', 'dark-reader'); ?>">
                <?php if ($style == 'default' || $style == 'round'): ?>
                    <span class="sun-icon">☀️</span>
                    <span class="moon-icon">🌙</span>
                <?php elseif ($style == 'switch'): ?>
                    <span class="switch-track"></span>
                    <span class="switch-thumb"></span>
                <?php elseif ($style == 'toggle'): ?>
                    <span class="toggle-track">
                        <span class="toggle-sun">☀️</span>
                        <span class="toggle-moon">🌙</span>
                    </span>
                    <span class="toggle-thumb"></span>
                <?php elseif ($style == 'minimal'): ?>
                    <span class="minimal-icon"></span>
                 <!-- elseif ($style == 'slider'): ?>
                    <span class="slider-container">
                        <span class="slider-background"></span>
                        <span class="slider-track">
                            <span class="slider-icon sun">☀️</span>
                            <span class="slider-icon moon">🌙</span>
                        </span>
                        <span class="slider-thumb"></span>
                    </span> -->
                <?php elseif ($style == 'modern-slider'): ?>

                <?php elseif ($style == 'text-toggle'): ?>
                    <span class="text-label light">Light</span>
                    <span class="text-label dark">Dark</span>
                <?php elseif ($style == 'flipflop-toggle'): ?>
                    <span class="flipflop-track"></span>
                    <span class="flipflop-thumb"></span>
                <?php elseif ($style == 'ios-toggle'): ?>
                    <div class="ios-toggle-track">
                        <span class="ios-toggle-text off">Light</span>
                        <span class="ios-toggle-text on">Dark</span>
                    </div>
                <?php elseif ($style == 'ios-toggle-icon'): ?>
                    <div class="ios-toggle-track">
                        <span class="ios-toggle-text off">☀️</span>
                        <span class="ios-toggle-text on">🌙</span>
                    </div>
                <?php elseif ($style == 'liquid-glass'): ?>
                    <div class="liquid-glass-icons">
                        <span class="glass-icon off">🌙</span>
                        <span class="glass-icon on">☀️</span>
                    </div>
                    <!-- Liquid glass uses CSS pseudo-elements -->
                <?php elseif ($style == 'custom'): ?>
                    <?php
                    $light_icon = get_option('dark_reader_pro_custom_light_icon', '☀️');
                    $dark_icon = get_option('dark_reader_pro_custom_dark_icon', '🌙');
                    
                    // Fallback to defaults if empty
                    if (empty($light_icon)) {
                        $light_icon = '☀️';
                    }
                    if (empty($dark_icon)) {
                        $dark_icon = '🌙';
                    }
                    
                    echo '<span class="custom-icon light-icon">' . esc_html($light_icon) . '</span>';
                    echo '<span class="custom-icon dark-icon">' . esc_html($dark_icon) . '</span>';
                    ?>
                <?php endif; ?>
            </button>
        </div>

        <?php
        return ob_get_clean();
    }
}

// Initialize the shortcode
new Dark_Reader_Toggle_Shortcode();
