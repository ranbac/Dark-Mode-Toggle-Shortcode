<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Shortcode service class.
 *
 * @package Dark_Mode_Toggle
 */

namespace DarkModeToggle;

defined( 'ABSPATH' ) || die();

class Shortcode extends Base implements Service {

	public function init() {
		add_shortcode( 'dark_mode_toggle', array( $this, 'render' ) );

		// Luôn ẩn floating button ngay từ <head>.
		add_action( 'wp_head', array( $this, 'output_hide_style' ), 1 );
	}

	public function output_hide_style() {
		echo '<style id="dmtg-hide-floating">.darkmode-toggle{display:none!important}</style>' . "\n";
	}

	public function render( $atts = array(), $content = '' ) {
		if ( ! wp_script_is( 'darkmodetg', 'enqueued' ) ) {
			$front = darkmodetg( 'options' )->get_main( 'front' );
			darkmodetg( 'utility' )->enqueue( $front );
		}

		$this->enqueue_switch_css();

		static $instance = 0;
		++$instance;
		$switch_id = 'dmtg-switch-' . $instance;

		ob_start();
		?>
		<span
			id="<?php echo esc_attr( $switch_id ); ?>"
			class="dmtg-switch"
			role="checkbox"
			tabindex="0"
			aria-checked="false"
			aria-label="<?php esc_attr_e( 'Toggle dark mode', 'dark-mode-toggle' ); ?>"
		>
			<span class="dmtg-switch__track">
				<span class="dmtg-switch__knob">
					<svg class="dmtg-switch__icon dmtg-switch__icon--moon" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
						<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
					</svg>
					<svg class="dmtg-switch__icon dmtg-switch__icon--sun" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">
						<circle cx="12" cy="12" r="4"/>
						<line x1="12" y1="2"  x2="12" y2="5"/>
						<line x1="12" y1="19" x2="12" y2="22"/>
						<line x1="2"  y1="12" x2="5"  y2="12"/>
						<line x1="19" y1="12" x2="22" y2="12"/>
						<line x1="4.93" y1="4.93"   x2="7.05" y2="7.05"/>
						<line x1="16.95" y1="16.95"  x2="19.07" y2="19.07"/>
						<line x1="4.93" y1="19.07"   x2="7.05" y2="16.95"/>
						<line x1="16.95" y1="7.05"   x2="19.07" y2="4.93"/>
					</svg>
				</span>
			</span>
		</span>
		<script>
		( function () {
			var switchId = <?php echo wp_json_encode( $switch_id ); ?>;

			function init() {
				var sw = document.getElementById( switchId );
				if ( ! sw ) { return; }

				function syncState() {
					var on = document.body.classList.contains( 'darkmode--activated' );
					sw.classList.toggle( 'dmtg-switch--on', on );
					sw.setAttribute( 'aria-checked', on ? 'true' : 'false' );
				}

				function doToggle() {
					var isOn = document.body.classList.contains( 'darkmode--activated' );
					var layer = document.querySelector( '.darkmode-layer' );

					// Toggle body class và lưu localStorage — giống hệt darkmode-js.
					document.body.classList.toggle( 'darkmode--activated' );
					try { window.localStorage.setItem( 'darkmode', String( ! isOn ) ); } catch(e) {}

					// Animate layer (transition effect của darkmode-js).
					if ( layer ) {
						if ( isOn ) {
							// Đang tắt dark mode.
							layer.classList.remove( 'darkmode-layer--simple' );
							setTimeout( function() {
								layer.classList.remove( 'darkmode-layer--no-transition' );
								layer.classList.remove( 'darkmode-layer--expanded' );
							}, 1 );
						} else {
							// Đang bật dark mode.
							layer.classList.add( 'darkmode-layer--expanded' );
							var time = 0;
							try {
								var style = window.getComputedStyle( layer );
								var tr = style.transitionDuration || '0s';
								time = Math.round( parseFloat( tr ) * 1000 );
							} catch(e) {}
							setTimeout( function() {
								layer.classList.add( 'darkmode-layer--no-transition' );
								layer.classList.add( 'darkmode-layer--simple' );
							}, time || 0 );
						}
					}

					syncState();
				}

				sw.addEventListener( 'click', doToggle );
				sw.addEventListener( 'keydown', function( e ) {
					if ( e.key === ' ' || e.key === 'Enter' ) {
						e.preventDefault();
						doToggle();
					}
				} );

				if ( window.MutationObserver ) {
					new MutationObserver( syncState ).observe(
						document.body,
						{ attributes: true, attributeFilter: [ 'class' ] }
					);
				}

				syncState();
			}

			if ( document.readyState === 'loading' ) {
				document.addEventListener( 'DOMContentLoaded', init );
			} else {
				init();
			}
		} )();
		</script>
		<?php
		return ob_get_clean();
	}

	private function enqueue_switch_css() {
		if ( wp_style_is( 'dmtg-shortcode', 'enqueued' ) ) {
			return;
		}

		$css = '
.dmtg-switch{display:inline-flex;align-items:center;cursor:pointer;vertical-align:middle;-webkit-user-select:none;user-select:none}
.dmtg-switch:focus-visible{outline:2px solid #4a90d9;outline-offset:3px;border-radius:20px}
.dmtg-switch__track{position:relative;width:52px;height:28px;border-radius:14px;background:#b0b0b0;transition:background .3s ease;box-sizing:border-box}
.dmtg-switch--on .dmtg-switch__track{background:#4a4a6a}
.dmtg-switch__knob{position:absolute;top:4px;left:4px;width:20px;height:20px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;transition:left .3s cubic-bezier(.4,0,.2,1),background .3s ease;box-shadow:0 1px 4px rgba(0,0,0,.25)}
.dmtg-switch--on .dmtg-switch__knob{left:28px;background:#c8c8e8}
.dmtg-switch__icon{display:none;flex-shrink:0}
.dmtg-switch__icon--sun{display:block;color:#b06000}
.dmtg-switch--on .dmtg-switch__icon--sun{display:none}
.dmtg-switch--on .dmtg-switch__icon--moon{display:block;color:#6060a8}
';

		wp_register_style( 'dmtg-shortcode', false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		wp_enqueue_style( 'dmtg-shortcode' );
		wp_add_inline_style( 'dmtg-shortcode', $css );
	}
}
