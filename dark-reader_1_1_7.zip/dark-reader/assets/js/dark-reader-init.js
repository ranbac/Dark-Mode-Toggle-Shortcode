/**
 * Dark Reader initialization script
 * Uses the darkreader.js library to add dark mode functionality to WordPress sites
 * Modern implementation with ES6+ features
 */

(() => {
    'use strict';

    /**
     * Get current page ID for localStorage key
     * @returns {string}
     */
    const getCurrentPageId = () => {
        const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
        return settings.currentPageId || 'default';
    };

    /**
     * Get page visibility mode
     * @returns {string}
     */
    const getPageVisibilityMode = () => {
        const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
        return settings.pageVisibilityMode || 'show_all';
    };

    /**
     * Check if current mode uses global localStorage
     * @returns {boolean}
     */
    const isGlobalMode = () => {
        const mode = getPageVisibilityMode();
        return mode === 'show_all' || mode === 'hide_all';
    };

    /**
     * Clean up localStorage when switching modes
     */
    const cleanupLocalStorage = () => {
        try {
            const mode = getPageVisibilityMode();
            const currentModeStored = localStorage.getItem('darkReaderVisibilityMode');

            // If mode has changed, clean up old localStorage entries
            if (currentModeStored && currentModeStored !== mode) {
                if (mode === 'show_all' || mode === 'hide_all') {
                    // Switching to global mode - remove all page-specific entries
                    Object.keys(localStorage).forEach(key => {
                        if (key.startsWith('darkReaderEnabled_')) {
                            localStorage.removeItem(key);
                        }
                    });
                } else {
                    // Switching to page-specific mode - remove global entry
                    localStorage.removeItem('darkReaderEnabled');
                }
            }

            // Store current mode
            localStorage.setItem('darkReaderVisibilityMode', mode);
        } catch (e) {
        }
    };

    /**
     * Get dark mode preference from localStorage or default settings
     * @returns {boolean} - Whether dark mode should be enabled
     */
    const getDarkModePreference = () => {
        try {
            cleanupLocalStorage();

            // Check if user has manually toggled (takes precedence over everything)
            const manualToggle = localStorage.getItem('darkReaderManualToggle');
            if (manualToggle === 'true') {
                if (isGlobalMode()) {
                    const global = localStorage.getItem('darkReaderEnabled');
                    if (global !== null) {
                        return global === '1';
                    }
                } else {
                    const pageId = getCurrentPageId();
                    const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                    const pageSpecific = localStorage.getItem(pageSpecificKey);

                    if (pageSpecific !== null) {
                        return pageSpecific === '1';
                    }
                }
            }

            // Check if system color scheme is enabled
            const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
            if (settings.useSystemColorScheme) {
                // Use system preference
                if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    return true;
                }
                if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
                    return false;
                }
            }

            // Check localStorage for saved preference (when not using system scheme or manual toggle)
            if (isGlobalMode()) {
                // Global modes: use single localStorage key
                const global = localStorage.getItem('darkReaderEnabled');
                if (global !== null) {
                    return global === '1';
                }
            } else {
                // Page-specific modes: use page-specific localStorage key
                const pageId = getCurrentPageId();
                const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                const pageSpecific = localStorage.getItem(pageSpecificKey);

                if (pageSpecific !== null) {
                    return pageSpecific === '1';
                }
            }
        } catch (e) {
        }

        // Check for default setting from WordPress
        return Boolean(typeof darkReaderSettings !== 'undefined' && darkReaderSettings && darkReaderSettings.defaultDarkMode);
    };

    /**
     * Apply critical dark mode styles immediately to prevent FOUC
     */
    const applyCriticalDarkStyles = () => {
        // Check if dark mode should be applied on this page (Pro feature)
        const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
        const shouldApplyOnThisPage = settings.shouldApplyDarkMode !== false;

        if (!shouldApplyOnThisPage) {
            return;
        }

        // Check user preference using the new localStorage logic
        // This will now also check system color scheme if enabled
        if (!getDarkModePreference()) {
            return;
        }

        // Create critical CSS to prevent flash of light mode
        const criticalCSS = `
            html {
                filter: invert(1) hue-rotate(180deg) !important;
                transition: filter 0.1s ease !important;
            }
            img, video, iframe, svg, 
            [style*="background-image"],
            canvas, embed, object {
                filter: invert(1) hue-rotate(180deg) !important;
            }
        `;

        const style = document.createElement('style');
        style.id = 'dark-reader-critical';
        style.textContent = criticalCSS;

        // Insert immediately, even before head is fully parsed
        if (document.head) {
            document.head.appendChild(style);
        } else {
            // If head doesn't exist yet, wait for it
            const observer = new MutationObserver((mutations, obs) => {
                if (document.head) {
                    document.head.appendChild(style);
                    obs.disconnect();
                }
            });
            observer.observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        }

        // Set data attribute immediately
        document.documentElement.setAttribute('data-darkreader-mode', 'critical');
        if (document.body) {
            document.body.classList.add('dark-mode');
        }
    };

    /**
     * Remove critical styles when DarkReader takes over
     */
    const removeCriticalStyles = () => {
        const criticalStyle = document.getElementById('dark-reader-critical');
        if (criticalStyle) {
            criticalStyle.remove();
        }

        // Also remove fallback critical styles and classes
        const fallbackStyle = document.getElementById('dark-reader-critical-fallback');
        if (fallbackStyle) {
            fallbackStyle.remove();
        }

        document.documentElement.classList.remove('dark-reader-critical-loading');
    };

    /**
     * Create Dark Reader fixes object from exclusions
     * @returns {Object} DarkReader fixes configuration
     */
    const createDarkReaderFixes = () => {
        const fixes = {
            ignoreInlineStyle: [],
            ignoreImageAnalysis: [],
            css: ''
        };

        // Always exclude toggle buttons from image analysis and transformations
        const toggleButtonSelectors = [
            '.dark-reader-toggle',
            '.dark-reader-toggle *',
            '.dark-reader-toggle-slider',
            '.dark-reader-toggle-switch',
            '[class*="dark-reader-toggle"]',
            '[class*="toggle-slider"]',
            '.dark-mode-toggle',
            '[data-dark-toggle]'
        ];

        // Add toggle buttons to ignoreImageAnalysis
        fixes.ignoreImageAnalysis.push(...toggleButtonSelectors);

        // Check if darkReaderSettings is available
        if (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) {
            let customCSS = '';



            // Check if darkReaderSettings has exclusions
            if (darkReaderSettings.exclusions) {

                let allExcludedSelectors = [];

                // Collect custom CSS selectors
                if (darkReaderSettings.exclusions.selectors) {
                    let selectors = [];
                    if (Array.isArray(darkReaderSettings.exclusions.selectors)) {
                        selectors = darkReaderSettings.exclusions.selectors.filter(selector =>
                            typeof selector === 'string' && selector.trim() !== ''
                        );
                    } else if (typeof darkReaderSettings.exclusions.selectors === 'string') {
                        // Handle case where selectors is a single string
                        selectors = darkReaderSettings.exclusions.selectors.split(',').map(s => s.trim()).filter(s => s !== '');
                    }

                    if (selectors.length > 0) {
                        allExcludedSelectors.push(...selectors);
                    }
                }

                // Add image exclusions
                if (darkReaderSettings.exclusions.images && Array.isArray(darkReaderSettings.exclusions.images)) {
                    const images = darkReaderSettings.exclusions.images.filter(selector =>
                        typeof selector === 'string' && selector.trim() !== ''
                    );

                    // Add to both CSS exclusions and DarkReader's ignoreImageAnalysis
                    allExcludedSelectors.push(...images);
                    fixes.ignoreImageAnalysis.push(...images);
                }

                // Add video exclusions
                if (darkReaderSettings.exclusions.videos && Array.isArray(darkReaderSettings.exclusions.videos)) {
                    const videos = darkReaderSettings.exclusions.videos.filter(selector =>
                        typeof selector === 'string' && selector.trim() !== ''
                    );

                    // Videos should be excluded via CSS, not ignoreImageAnalysis
                    allExcludedSelectors.push(...videos);
                }

                // Create CSS to exclude elements from dark mode transformation
                if (allExcludedSelectors.length > 0) {
                    const selectorString = allExcludedSelectors.join(', ');
                    const exclusionCSS = `
                    /* Dark Reader Pro Element Exclusions */
                    ${selectorString} {
                        filter: none !important;
                        backdrop-filter: none !important;
                        color-scheme: initial !important;
                        color: initial !important;
                        --darkreader-inline-color: initial !important;
                        -webkit-filter: none !important;
                    }
                    ${selectorString} * {
                        filter: none !important;
                        backdrop-filter: none !important;
                        -webkit-filter: none !important;
                    }
                `;
                    customCSS += exclusionCSS;
                }

                // Set the final CSS
                if (customCSS) {
                    fixes.css = customCSS;
                }
            }

        } else {
        }

        // Always add toggle button exclusion CSS
        const toggleExclusionCSS = `
        /* Dark Reader Toggle Button Exclusions */
        .dark-reader-toggle,
        .dark-reader-toggle *,
        .dark-reader-toggle-slider,
        .dark-reader-toggle-slider:before,
        .dark-reader-toggle-slider:after,
        .dark-reader-toggle-switch,
        .dark-reader-toggle-switch *,
        [class*="dark-reader-toggle"],
        [class*="toggle-slider"],
        .dark-mode-toggle,
        [data-dark-toggle] {
            filter: none !important;
            backdrop-filter: none !important;
            -webkit-filter: none !important;
            --darkreader-inline-bgcolor: initial !important;
            --darkreader-inline-bgimage: initial !important;
            --darkreader-inline-border: initial !important;
            --darkreader-inline-color: initial !important;
        }
        `;
        
        fixes.css = (fixes.css || '') + toggleExclusionCSS;

        return fixes;
    };

    /**
     * Create Dark Reader configuration object
     * Builds config from WordPress settings with sensible defaults
     * @returns {Object} DarkReader configuration
     */
    const createDarkReaderConfig = () => {
        // Use default values if darkReaderSettings is not available
        const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};

        const config = {
            brightness: parseInt(settings.brightness) || 100,
            contrast: parseInt(settings.contrast) || 90,
            sepia: parseInt(settings.sepia) || 10,
            grayscale: parseInt(settings.grayscale) || 0,
            textStroke: parseFloat(settings.textStroke) || 0,
            mode: parseInt(settings.mode) === 0 ? 0 : 1,
            enableForPDFs: Boolean(settings.enableForPDFs),
            immediateModify: settings.immediateModify !== false
        };

        // Add dark scheme colors if provided
        if (settings.darkSchemeBackgroundColor) {
            config.darkSchemeBackgroundColor = settings.darkSchemeBackgroundColor;
        }
        if (settings.darkSchemeTextColor) {
            config.darkSchemeTextColor = settings.darkSchemeTextColor;
        }

        return config;
    };

    // Note: darkReaderFixes is created on-demand in functions to avoid timing issues

    /**
     * Store dark mode preference in localStorage
     * @param {boolean} isDark - Whether dark mode is enabled
     */
    const setDarkModePreference = (isDark) => {
        try {

            if (isGlobalMode()) {
                // Global modes: set global preference
                localStorage.setItem('darkReaderEnabled', isDark ? '1' : '0');
            } else {
                // Page-specific modes: set page-specific preference
                const pageId = getCurrentPageId();
                const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                localStorage.setItem(pageSpecificKey, isDark ? '1' : '0');
            }

            // Set manual toggle flag
            localStorage.setItem('darkReaderManualToggle', 'true');

            // Dispatch custom event for analytics tracking
            document.dispatchEvent(new CustomEvent('darkReaderToggled', {
                detail: { isDark: isDark }
            }));
        } catch (e) {
        }
    };

    /**
     * Initialize dark mode based on user preference and page settings
     */
    const initDarkMode = () => {
        try {
            const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
            const shouldApplyOnThisPage = settings.shouldApplyDarkMode !== false;
            const userPreference = getDarkModePreference();

            if (shouldApplyOnThisPage && userPreference) {
                // Enable dark mode
                try {
                    const config = createDarkReaderConfig();
                    const fixes = createDarkReaderFixes();
                    DarkReader.enable(config, fixes);
                    removeCriticalStyles();
                    document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                    if (document.body) {
                        document.body.classList.add('dark-mode');
                    }

                    // Initialize PDF dark mode if enabled
                    if (settings.enableForPDFs) {
                        initPDFDarkMode();
                    }
                } catch (error) {
                    // Fallback: enable without fixes
                    const config = createDarkReaderConfig();
                    DarkReader.enable(config);
                    removeCriticalStyles();
                    document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                    if (document.body) {
                        document.body.classList.add('dark-mode');
                    }

                    // Initialize PDF dark mode if enabled
                    if (settings.enableForPDFs) {
                        initPDFDarkMode();
                    }
                }
            } else {
                // Disable dark mode
                DarkReader.disable();
                removeCriticalStyles();
                document.documentElement.setAttribute('data-darkreader-mode', 'light');
                if (document.body) {
                    document.body.classList.remove('dark-mode');
                }

                // Disable PDF dark mode
                disablePDFDarkMode();
            }

            updateToggleButton(userPreference);
        } catch (e) {
        }
    };

    /**
     * Initialize PDF dark mode functionality
     */
    const initPDFDarkMode = () => {
        try {
            // Check if PDF dark mode is enabled
            const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
            if (!settings.enableForPDFs) {
                return;
            }

            // Load PDF.js if not already loaded
            loadPDFJS().then(() => {
                // Set up PDF viewer detection and dark mode
                setupPDFViewerDarkMode();
            }).catch(error => {
            });
        } catch (e) {
        }
    };

    /**
     * Load PDF.js library dynamically
     */
    const loadPDFJS = async () => {
        // Check if PDF.js is already loaded
        if (typeof pdfjsLib !== 'undefined') {
            return Promise.resolve();
        }

        // Load PDF.js from CDN
        const pdfjsScript = document.createElement('script');
        pdfjsScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        pdfjsScript.async = true;

        return new Promise((resolve, reject) => {
            pdfjsScript.onload = () => {
                // Set worker path
                if (typeof pdfjsLib !== 'undefined') {
                    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
                    resolve();
                } else {
                    reject(new Error('PDF.js failed to load'));
                }
            };
            pdfjsScript.onerror = () => reject(new Error('Failed to load PDF.js'));
            document.head.appendChild(pdfjsScript);
        });
    };

    /**
     * Set up PDF viewer dark mode
     */
    const setupPDFViewerDarkMode = () => {
        try {
            // Detect different types of PDF viewers
            const pdfElements = document.querySelectorAll('embed[type="application/pdf"], object[type="application/pdf"], iframe[src*=".pdf"], iframe[src*="blob:"]');

            pdfElements.forEach(element => {
                applyDarkModeToPDFElement(element);
            });

            // Watch for dynamically added PDF elements
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if the added node is a PDF element
                            if (isPDFElement(node)) {
                                applyDarkModeToPDFElement(node);
                            }

                            // Check children of added node
                            const pdfChildren = node.querySelectorAll('embed[type="application/pdf"], object[type="application/pdf"], iframe[src*=".pdf"], iframe[src*="blob:"]');
                            pdfChildren.forEach(element => {
                                applyDarkModeToPDFElement(element);
                            });
                        }
                    });
                });
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // Store observer for cleanup
            window.darkReaderPDFObserver = observer;
        } catch (e) {
        }
    };

    /**
     * Check if an element is a PDF element
     */
    const isPDFElement = (element) => {
        if (!element || !element.tagName) return false;

        const tagName = element.tagName.toLowerCase();
        const type = element.getAttribute('type');
        const src = element.getAttribute('src');

        return (
            (tagName === 'embed' && type === 'application/pdf') ||
            (tagName === 'object' && type === 'application/pdf') ||
            (tagName === 'iframe' && (src?.includes('.pdf') || src?.startsWith('blob:')))
        );
    };

    /**
     * Apply dark mode to a PDF element
     */
    const applyDarkModeToPDFElement = (element) => {
        try {
            if (!element) return;

            // Add dark mode class to PDF container
            element.classList.add('dark-reader-pdf-dark');

            // Create dark mode overlay for PDF
            createPDFDarkOverlay(element);

            // Apply CSS filters for browser PDF viewers
            applyPDFCSSFilters(element);

            // Handle iframe PDF viewers (like browser built-in viewers)
            if (element.tagName.toLowerCase() === 'iframe') {
                handleIframePDFViewer(element);
            }
        } catch (e) {
        }
    };

    /**
     * Create dark mode overlay for PDF elements
     */
    const createPDFDarkOverlay = (element) => {
        try {
            // Remove existing overlay if any
            const existingOverlay = element.parentNode?.querySelector('.dark-reader-pdf-overlay');
            if (existingOverlay) {
                existingOverlay.remove();
            }

            // Create overlay
            const overlay = document.createElement('div');
            overlay.className = 'dark-reader-pdf-overlay';
            overlay.style.cssText = `
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.1);
                pointer-events: none;
                z-index: 1;
                opacity: 0;
                transition: opacity 0.3s ease;
            `;

            // Position the element relatively if not already
            const computedStyle = window.getComputedStyle(element);
            if (computedStyle.position === 'static') {
                element.style.position = 'relative';
            }

            // Insert overlay
            element.parentNode.insertBefore(overlay, element.nextSibling);

            // Show overlay
            setTimeout(() => {
                overlay.style.opacity = '1';
            }, 100);
        } catch (e) {
        }
    };

    /**
     * Apply CSS filters for browser PDF viewers
     */
    const applyPDFCSSFilters = (element) => {
        try {
            const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};

            // Create filter string based on settings
            const brightness = settings.brightness || 100;
            const contrast = settings.contrast || 90;
            const sepia = settings.sepia || 10;
            const grayscale = settings.grayscale || 0;

            const filterString = `
                brightness(${brightness}%) 
                contrast(${contrast}%) 
                sepia(${sepia}%) 
                grayscale(${grayscale}%)
                invert(1) 
                hue-rotate(180deg)
            `;

            element.style.filter = filterString;
            element.style.transition = 'filter 0.3s ease';
        } catch (e) {
        }
    };

    /**
     * Handle iframe PDF viewers (browser built-in viewers)
     */
    const handleIframePDFViewer = (iframe) => {
        try {
            // Wait for iframe to load
            iframe.addEventListener('load', () => {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                    if (!iframeDoc) return;

                    // Apply dark mode to iframe content
                    applyDarkModeToIframeContent(iframeDoc);
                } catch (e) {
                    // Cross-origin iframe, can't access content
                }
            });
        } catch (e) {
        }
    };

    /**
     * Apply dark mode to iframe content
     */
    const applyDarkModeToIframeContent = (iframeDoc) => {
        try {
            // Add dark mode styles to iframe
            const darkStyles = iframeDoc.createElement('style');
            darkStyles.textContent = `
                body {
                    background-color: #1a1a1a !important;
                    color: #ffffff !important;
                }
                * {
                    background-color: #1a1a1a !important;
                    color: #ffffff !important;
                    border-color: #333333 !important;
                }
                canvas {
                    filter: invert(1) hue-rotate(180deg) !important;
                }
            `;
            iframeDoc.head.appendChild(darkStyles);
        } catch (e) {
        }
    };

    /**
     * Disable PDF dark mode
     */
    const disablePDFDarkMode = () => {
        try {
            // Remove PDF dark mode classes
            document.querySelectorAll('.dark-reader-pdf-dark').forEach(element => {
                element.classList.remove('dark-reader-pdf-dark');
                element.style.filter = '';
            });

            // Remove overlays
            document.querySelectorAll('.dark-reader-pdf-overlay').forEach(overlay => {
                overlay.remove();
            });

            // Stop observer
            if (window.darkReaderPDFObserver) {
                window.darkReaderPDFObserver.disconnect();
                window.darkReaderPDFObserver = null;
            }
        } catch (e) {
        }
    };

    /**
     * Toggle dark mode on/off
     */
    const toggleDarkMode = () => {
        const isDarkModeOn = getDarkModePreference();

        // Check if dark mode should be applied on this page (Pro feature)
        const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
        const shouldApplyOnThisPage = settings.shouldApplyDarkMode !== false;

        try {
            if (isDarkModeOn) {
                // Switch to light mode
                DarkReader.disable();
                removeCriticalStyles();
                document.documentElement.setAttribute('data-darkreader-mode', 'light');
                if (document.body) {
                    document.body.classList.remove('dark-mode');
                }
                setDarkModePreference(false);

                // Disable PDF dark mode
                disablePDFDarkMode();
            } else {
                // Check if dark mode is allowed on this page before enabling
                if (!shouldApplyOnThisPage) {
                    // Don't enable dark mode on pages where it's not allowed
                    return;
                }

                // Switch to dark mode
                try {
                    const config = createDarkReaderConfig();
                    const fixes = createDarkReaderFixes();
                    DarkReader.enable(config, fixes);
                    removeCriticalStyles();
                    document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                    if (document.body) {
                        document.body.classList.add('dark-mode');
                    }
                    setDarkModePreference(true);

                    // Initialize PDF dark mode if enabled
                    const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
                    if (settings.enableForPDFs) {
                        initPDFDarkMode();
                    }
                } catch (error) {
                    // Fallback: enable without fixes
                    const config = createDarkReaderConfig();
                    DarkReader.enable(config);
                    removeCriticalStyles();
                    document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                    if (document.body) {
                        document.body.classList.add('dark-mode');
                    }
                    setDarkModePreference(true);

                    // Initialize PDF dark mode if enabled
                    const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};
                    if (settings.enableForPDFs) {
                        initPDFDarkMode();
                    }
                }
            }

            updateToggleButton(!isDarkModeOn);
        } catch (e) {
        }
    };

    // Expose for Pro accessibility (keyboard shortcut, URL params) so they use the same
    // config, fixes, localStorage format, and manual-toggle flag as the UI toggle.
    window.darkReaderToggle = toggleDarkMode;
    window.darkReaderInitDarkMode = initDarkMode;
    window.darkReaderSetPreferenceAndApply = (enabled) => {
        setDarkModePreference(enabled);
        initDarkMode();
    };

    /**
     * Update toggle button appearance based on dark mode state
     * @param {boolean} isDark - Whether dark mode is enabled
     */
    const updateToggleButton = (isDark) => {
        const toggleButton = document.getElementById('dark-reader-toggle');

        try {
            // Update main toggle button if it exists
            if (toggleButton) {
                toggleButton.classList.toggle('dark', isDark);
            }

            // Update all other inline toggle buttons (from shortcodes)
            document.querySelectorAll('.dark-reader-toggle-inline').forEach(container => {
                container.classList.toggle('dark', isDark);
            });
        } catch (e) {
        }
    };

    /**
     * Set up event listeners
     */
    const setupEventListeners = () => {
        try {
            // Main toggle button
            const toggleButton = document.getElementById('dark-reader-toggle');
            if (toggleButton) {
                toggleButton.addEventListener('click', toggleDarkMode);
            }

            document.querySelectorAll('.dark-reader-toggle-inline').forEach(container => {
                container.addEventListener('click', toggleDarkMode);
            });

            // Set up system color scheme listener if enabled
            setupSystemColorSchemeListener();
        } catch (e) {
        }
    };

    /**
     * Set up system color scheme listener
     * Listens for changes in OS dark mode preference and applies them automatically
     */
    const setupSystemColorSchemeListener = () => {
        try {
            const settings = (typeof darkReaderSettings !== 'undefined' && darkReaderSettings) ? darkReaderSettings : {};

            // Only set up listener if system color scheme is enabled
            if (!settings.useSystemColorScheme) {
                return;
            }

            // Check if matchMedia is supported (should be on all modern browsers including iOS)
            if (!window.matchMedia) {
                return;
            }

            const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');

            // Handler for system color scheme changes
            const handleSystemColorSchemeChange = (e) => {
                // Don't auto-switch if user has manually toggled
                const manualToggle = localStorage.getItem('darkReaderManualToggle');
                if (manualToggle === 'true') {
                    return;
                }

                const shouldApplyOnThisPage = settings.shouldApplyDarkMode !== false;
                if (!shouldApplyOnThisPage) {
                    return;
                }

                const prefersDark = e.matches;

                if (prefersDark) {
                    // System switched to dark mode - enable dark reader
                    try {
                        const config = createDarkReaderConfig();
                        const fixes = createDarkReaderFixes();
                        DarkReader.enable(config, fixes);
                        removeCriticalStyles();
                        document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                        if (document.body) {
                            document.body.classList.add('dark-mode');
                        }

                        // Store preference without setting manual toggle flag
                        try {
                            if (isGlobalMode()) {
                                localStorage.setItem('darkReaderEnabled', '1');
                            } else {
                                const pageId = getCurrentPageId();
                                const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                                localStorage.setItem(pageSpecificKey, '1');
                            }
                        } catch (err) { }

                        // Initialize PDF dark mode if enabled
                        if (settings.enableForPDFs) {
                            initPDFDarkMode();
                        }
                    } catch (error) {
                        // Fallback: enable without fixes
                        const config = createDarkReaderConfig();
                        DarkReader.enable(config);
                        removeCriticalStyles();
                        document.documentElement.setAttribute('data-darkreader-mode', 'dynamic');
                        if (document.body) {
                            document.body.classList.add('dark-mode');
                        }

                        try {
                            if (isGlobalMode()) {
                                localStorage.setItem('darkReaderEnabled', '1');
                            } else {
                                const pageId = getCurrentPageId();
                                const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                                localStorage.setItem(pageSpecificKey, '1');
                            }
                        } catch (err) { }

                        if (settings.enableForPDFs) {
                            initPDFDarkMode();
                        }
                    }
                } else {
                    // System switched to light mode - disable dark reader
                    DarkReader.disable();
                    removeCriticalStyles();
                    document.documentElement.setAttribute('data-darkreader-mode', 'light');
                    if (document.body) {
                        document.body.classList.remove('dark-mode');
                    }

                    // Store preference without setting manual toggle flag
                    try {
                        if (isGlobalMode()) {
                            localStorage.setItem('darkReaderEnabled', '0');
                        } else {
                            const pageId = getCurrentPageId();
                            const pageSpecificKey = `darkReaderEnabled_${pageId}`;
                            localStorage.setItem(pageSpecificKey, '0');
                        }
                    } catch (err) { }

                    // Disable PDF dark mode
                    disablePDFDarkMode();
                }

                updateToggleButton(prefersDark);
            };

            // Add listener using modern method (iOS 14+)
            if (darkModeQuery.addEventListener) {
                darkModeQuery.addEventListener('change', handleSystemColorSchemeChange);
            }
            // Fallback for older iOS versions (iOS 13 and below)
            else if (darkModeQuery.addListener) {
                darkModeQuery.addListener(handleSystemColorSchemeChange);
            }

        } catch (e) {
        }
    };

    // Apply critical styles immediately to prevent FOUC
    applyCriticalDarkStyles();

    // Early initialization - check if we can initialize immediately
    if (typeof DarkReader !== 'undefined') {
        initDarkMode();
        setupEventListeners();
    }

    // Initialize when DOM is fully loaded
    document.addEventListener('DOMContentLoaded', () => {

        // Check if DarkReader library is available
        if (typeof DarkReader === 'undefined') {
            return;
        }

        // Initialize dark mode
        initDarkMode();

        // Set up event listeners
        setupEventListeners();

        // Make debug functions available globally for testing
        window.darkReaderDebug = {
            getSettings: () => typeof darkReaderSettings !== 'undefined' ? darkReaderSettings : 'undefined',
            getExclusions: () => {
                if (typeof darkReaderSettings !== 'undefined' && darkReaderSettings && darkReaderSettings.exclusions) {
                    return darkReaderSettings.exclusions;
                }
                return 'No exclusions found';
            },
            testFixes: () => {
                const fixes = createDarkReaderFixes();
                return fixes;
            },
            reloadDarkMode: () => {
                initDarkMode();
            },
            testExclusions: () => {

                if (typeof darkReaderSettings !== 'undefined' && darkReaderSettings.exclusions) {

                    const fixes = createDarkReaderFixes();

                    // Test if excluded elements exist on page
                    if (darkReaderSettings.exclusions.images) {
                        darkReaderSettings.exclusions.images.forEach(selector => {
                            const elements = document.querySelectorAll(selector);
                        });
                    }

                    if (darkReaderSettings.exclusions.videos) {
                        darkReaderSettings.exclusions.videos.forEach(selector => {
                            const elements = document.querySelectorAll(selector);
                        });
                    }
                } else {
                }

                return 'Test completed';
            }
        };
    });
})();