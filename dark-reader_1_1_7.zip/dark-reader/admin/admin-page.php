<?php

/**
 * Dark Reader Admin Class
 *
 * Handles all admin-related functionality for the Dark Reader plugin.
 *
 * @package Dark Reader
 * @since 1.1.6
 */

// Exit if accessed directly
if (!defined('WPINC')) {
    die(esc_html__('Direct access not permitted.', 'dark-reader'));
}

use Bdthemes\DarkReaderPro\DarkReaderPro;

/**
 * Dark_Reader_Admin Class
 */
class Dark_Reader_Admin
{

    /**
     * Instance of this class.
     *
     * @since 1.1.6
     * @var object
     */
    protected static $instance = null;

    /**
     * Plugin version.
     *
     * @since 1.1.6
     * @var string
     */
    private $version;

    /**
     * Plugin slug.
     *
     * @since 1.1.6
     * @var string
     */
    private $plugin_slug = 'dark-reader';

    /**
     * Option names used in the admin page.
     *
     * @since 1.1.6
     * @var array
     */
    private $option_names = array(
        'brightness' => 'dark_reader_brightness',
        'contrast' => 'dark_reader_contrast',
        'sepia' => 'dark_reader_sepia',
        'grayscale' => 'dark_reader_grayscale',
        'text_stroke' => 'dark_reader_text_stroke',
        'filter_mode' => 'dark_reader_filter_mode',
        'default_dark_mode' => 'dark_reader_default_dark_mode',
        'toggle_position' => 'dark_reader_toggle_position',
        'toggle_style' => 'dark_reader_toggle_style',
        'use_system_color_scheme' => 'dark_reader_use_system_color_scheme',
        'enable_for_pdfs' => 'dark_reader_enable_for_pdfs',
        'immediate_modify' => 'dark_reader_immediate_modify',
        'dark_scheme_background' => 'dark_reader_dark_scheme_background',
        'dark_scheme_text' => 'dark_reader_dark_scheme_text',
    );

    /**
     * Initialize the class.
     *
     * @since 1.1.6
     */
    private function __construct()
    {
        $this->version = Dark_Reader::get_instance()->get_version();
        $this->setup_hooks();
    }

    /**
     * Return an instance of this class.
     *
     * @since 1.1.6
     * @return object A single instance of this class.
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Set up WordPress hooks and filters.
     *
     * @since 1.1.6
     * @return void
     */
    private function setup_hooks()
    {
        // Add menu item
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // AJAX handler for saving settings
        add_action('wp_ajax_dark_reader_save_settings', array($this, 'handle_save_settings'));

        // AJAX handler for exporting settings
        add_action('wp_ajax_dark_reader_export_settings', array($this, 'handle_export_settings'));

        // AJAX handler for importing settings
        add_action('wp_ajax_dark_reader_import_settings', array($this, 'handle_import_settings'));

        //redirect to settings page after activation
        add_action('admin_init', [$this, 'redirect_to_welcome_screen']);

        // Hook for pro version admin integration
        do_action('dark_reader_admin_loaded', $this);
    }



    /**
     * Redirect to Welcome page after activation.
     */
    public function redirect_to_welcome_screen()
    {
        // Bail if no activation redirect.
        if (!get_transient('_dark_reader_welcome_screen_activation_redirect')) {
            return;
        }

        // Delete the redirect transient.
        delete_transient('_dark_reader_welcome_screen_activation_redirect');

        // Bail if activating from network, or bulk.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (is_network_admin() || isset($_GET['activate-multi'])) {
            return;
        }

        // Redirect to welcome page.
        wp_safe_redirect(admin_url('admin.php?page=' . $this->plugin_slug . '-settings'));
    }


    /**
     * Register the administration menu for this plugin.
     *
     * @since 1.1.6
     * @return void
     */
    public function add_admin_menu()
    {
        // Add main menu page
        add_menu_page(
            __('Dark Reader Settings', 'dark-reader'),
            __('Dark Reader', 'dark-reader'),
            'manage_options',
            $this->plugin_slug . '-settings',
            array($this, 'display_admin_page'),
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>'),
            30
        );

        // Rename the first submenu to match the parent (required by WordPress)
        add_submenu_page(
            $this->plugin_slug . '-settings',
            __('Appearance', 'dark-reader'),
            __('Appearance', 'dark-reader'),
            'manage_options',
            $this->plugin_slug . '-settings',
            array($this, 'display_admin_page')
        );

        // Add submenu pages for each tab
        $submenu_pages = array(
            array(
                'page_title' => __('Toggle Button', 'dark-reader'),
                'menu_title' => __('Toggle Button', 'dark-reader'),
                'menu_slug' => $this->plugin_slug . '-toggle',
                'tab' => 'dark-reader-tab-toggle'
            ),
            array(
                'page_title' => __('Advanced', 'dark-reader'),
                'menu_title' => __('Advanced', 'dark-reader'),
                'menu_slug' => $this->plugin_slug . '-advanced',
                'tab' => 'dark-reader-tab-advanced'
            ),
            array(
                'page_title' => __('Colors', 'dark-reader'),
                'menu_title' => __('Colors', 'dark-reader'),
                'menu_slug' => $this->plugin_slug . '-colors',
                'tab' => 'dark-reader-tab-colors'
            ),
        );

        // Add Pro submenu items if Pro is active
        if (Dark_Reader::get_instance()->is_pro_active()) {
            $pro_submenu_pages = array(
                array(
                    'page_title' => __('Custom CSS', 'dark-reader'),
                    'menu_title' => __('Custom CSS', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-custom-css',
                    'tab' => 'dark-reader-tab-pro-custom-css'
                ),
                array(
                    'page_title' => __('Exclusions', 'dark-reader'),
                    'menu_title' => __('Exclusions', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-exclusions',
                    'tab' => 'dark-reader-tab-pro-exclusions'
                ),
                array(
                    'page_title' => __('Schedule', 'dark-reader'),
                    'menu_title' => __('Schedule', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-schedule',
                    'tab' => 'dark-reader-tab-pro-schedule'
                ),
                array(
                    'page_title' => __('Page Visibility', 'dark-reader'),
                    'menu_title' => __('Page Visibility', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-page-visibility',
                    'tab' => 'dark-reader-tab-pro-page-visibility'
                ),
                array(
                    'page_title' => __('Admin Dark Mode', 'dark-reader'),
                    'menu_title' => __('Admin Dark Mode', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-admin-dark-mode',
                    'tab' => 'dark-reader-tab-pro-admin'
                ),
                array(
                    'page_title' => __('Dark Mode Analytics', 'dark-reader'),
                    'menu_title' => __('Dark Mode Analytics', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-analytics',
                    'tab' => 'dark-reader-tab-pro-analytics'
                ),
                array(
                    'page_title' => __('Accessibility', 'dark-reader'),
                    'menu_title' => __('Accessibility', 'dark-reader'),
                    'menu_slug' => $this->plugin_slug . '-accessibility',
                    'tab' => 'dark-reader-tab-pro-accessibility'
                ),
            );
            $submenu_pages = array_merge($submenu_pages, $pro_submenu_pages);
        }

        // Add Help & Support submenu
        $submenu_pages[] = array(
            'page_title' => __('Help & Support', 'dark-reader'),
            'menu_title' => __('Help & Support', 'dark-reader'),
            'menu_slug' => $this->plugin_slug . '-help',
            'tab' => 'dark-reader-tab-help'
        );

        // Add Export/Import Settings submenu
        $submenu_pages[] = array(
            'page_title' => __('Export / Import Settings', 'dark-reader'),
            'menu_title' => __('Export / Import', 'dark-reader'),
            'menu_slug' => $this->plugin_slug . '-export-import',
            'tab' => 'dark-reader-tab-export-import'
        );

        // Add License submenu if Pro is active
        if (Dark_Reader::get_instance()->is_pro_active()) {
            // Check if license is valid
            $is_license_valid = Dark_Reader::get_instance()->has_valid_pro_license();

            // Highlight based on license status
            if (!$is_license_valid) {
                // License not activated - show in red with warning
                $license_menu_title = '<span style="color: #ff6b6b; font-weight: 600;">' . __('License Required', 'dark-reader') . '<span class="dashicons dashicons-warning" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle;"></span></span>';
            } else {
                // License activated - show in green with checkmark
                $license_menu_title = '<span style="color: #00d084; font-weight: 600;">' . __('License Activated', 'dark-reader') . '<span class="dashicons dashicons-yes" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle;"></span></span>';
            }

            $submenu_pages[] = array(
                'page_title' => __('License', 'dark-reader'),
                'menu_title' => $license_menu_title,
                'menu_slug' => $this->plugin_slug . '-license',
                'tab' => 'dark-reader-tab-license'
            );
        }

        // Register all submenu pages
        foreach ($submenu_pages as $submenu) {
            add_submenu_page(
                $this->plugin_slug . '-settings',
                $submenu['page_title'],
                $submenu['menu_title'],
                'manage_options',
                $submenu['menu_slug'],
                array($this, 'display_admin_page')
            );
            
            // Add Recommended Plugins right after Export/Import settings
            if ($submenu['menu_slug'] === $this->plugin_slug . '-export-import') {
                add_submenu_page(
                    $this->plugin_slug . '-settings',
                    __('Recommended Plugins', 'dark-reader'),
                    __('Recommended Plugins', 'dark-reader'),
                    'manage_options',
                    'plugin-install.php?s=bdthemes&tab=search&type=author'
                );
            }
        }

        // Note: Promotion submenu is now dynamically added via JavaScript API (see dark-reader-admin-biggopti.js)
    }


    /**
     * Enqueue admin-specific scripts and styles.
     *
     * @since 1.1.6
     * @param string $hook Current admin page.
     * @return void
     */
    public function enqueue_admin_assets($hook)
    {

        // Enqueue admin styles
        wp_enqueue_style(
            $this->plugin_slug . '-admin-style',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/css/dark-reader-admin.css',
            array(),
            $this->version
        );

        // Enqueue admin biggopti styles (for all admin pages)
        wp_enqueue_style(
            $this->plugin_slug . '-admin-biggopti',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/css/dark-reader-admin-biggopti.css',
            array(),
            $this->version
        );

        // Enqueue pro admin toggle styles if pro version exists
        if (Dark_Reader::get_instance()->has_valid_pro_license()) {
            wp_enqueue_style(
                'dark-reader-pro-admin-toggle',
                DarkReaderPro::get_instance()->get_plugin_url() . 'assets/css/dark-reader-admin-toggle.css',
                array(),
                DarkReaderPro::get_instance()->get_version()
            );
        }

        // Enqueue WordPress color picker
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // Enqueue jQuery
        wp_enqueue_script('jquery');

        // Enqueue admin script
        wp_enqueue_script(
            $this->plugin_slug . '-admin-script',
            Dark_Reader::get_instance()->get_plugin_url() . 'assets/js/dark-reader-admin.js',
            array('jquery', 'wp-color-picker'),
            $this->version,
            true
        );

        // Pass data to admin script
        wp_localize_script(
            $this->plugin_slug . '-admin-script',
            'darkReaderAdmin',
            array(
                'nonce' => wp_create_nonce('dark_reader_admin_nonce'),
                'pluginUrl' => Dark_Reader::get_instance()->get_plugin_url()
            )
        );
    }

    /**
     * Handle AJAX request to save settings.
     *
     * @since 1.1.6
     * @return void
     */
    public function handle_save_settings()
    {
        // Check nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'dark_reader_admin_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed', 'dark-reader')));
        }

        // Check user capability
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => esc_html__('You do not have permission to modify these settings', 'dark-reader')));
        }

        // Check for settings data
        if (!isset($_POST['settings'])) {
            wp_send_json_error(array('message' => esc_html__('No settings data received', 'dark-reader')));
        }

        // Parse settings data - use wp_unslash without sanitize_text_field to preserve CSS content
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- CSS input needs to remain unsanitized
        parse_str(wp_unslash($_POST['settings']), $settings);

        // Process and save each setting
        $this->save_settings($settings);

        // Allow pro version to save additional settings
        do_action('dark_reader_save_pro_settings', $settings);

        // Send success response
        wp_send_json_success(array('message' => esc_html__('Settings saved successfully', 'dark-reader')));
    }

    /**
     * Save plugin settings with proper validation.
     *
     * @since 1.1.6
     * @param array $settings Settings to save.
     * @return void
     */
    private function save_settings($settings)
    {
        // Boolean options (checkboxes)
        $boolean_options = array(
            $this->option_names['default_dark_mode'],
            $this->option_names['use_system_color_scheme'],
            $this->option_names['enable_for_pdfs'],
            $this->option_names['immediate_modify']
        );

        // Handle all boolean options (checkboxes)
        foreach ($boolean_options as $option) {
            $value = isset($settings[$option]) && $settings[$option] == '1';
            update_option($option, $value);
        }

        // Numeric options with ranges
        $numeric_ranges = array(
            $this->option_names['brightness'] => array('min' => 50, 'max' => 150),
            $this->option_names['contrast'] => array('min' => 50, 'max' => 150),
            $this->option_names['sepia'] => array('min' => 0, 'max' => 100),
            $this->option_names['grayscale'] => array('min' => 0, 'max' => 100),
        );

        // Handle numeric options with range validation
        foreach ($numeric_ranges as $option => $range) {
            if (isset($settings[$option])) {
                $value = intval($settings[$option]);
                $value = max($range['min'], min($range['max'], $value)); // Clamp to valid range
                update_option($option, $value);
            }
        }

        // Text stroke (float 0-1)
        if (isset($settings[$this->option_names['text_stroke']])) {
            $value = floatval($settings[$this->option_names['text_stroke']]);
            $value = max(0, min(1, $value)); // Clamp to 0-1
            update_option($this->option_names['text_stroke'], $value);
        }

        // Filter mode (0 or 1)
        if (isset($settings[$this->option_names['filter_mode']])) {
            $value = intval($settings[$this->option_names['filter_mode']]) ? 1 : 0;
            update_option($this->option_names['filter_mode'], $value);
        }

        // Toggle position
        if (isset($settings[$this->option_names['toggle_position']])) {
            $allowed_positions = array('top-left', 'top-right', 'bottom-left', 'bottom-right');
            $value = in_array($settings[$this->option_names['toggle_position']], $allowed_positions)
                ? $settings[$this->option_names['toggle_position']]
                : 'bottom-right';
            update_option($this->option_names['toggle_position'], $value);
        }

        // Toggle style - get allowed styles including pro styles
        if (isset($settings[$this->option_names['toggle_style']])) {
            $allowed_styles = array_keys(Dark_Reader::get_instance()->get_toggle_styles());
            $value = in_array($settings[$this->option_names['toggle_style']], $allowed_styles)
                ? $settings[$this->option_names['toggle_style']]
                : 'default';
            update_option($this->option_names['toggle_style'], $value);
        }

        // Color options
        $color_options = array(
            $this->option_names['dark_scheme_background'],
            $this->option_names['dark_scheme_text'],
        );

        foreach ($color_options as $option) {
            if (isset($settings[$option])) {
                if (empty($settings[$option])) {
                    // Allow empty values for colors to use defaults
                    update_option($option, '');
                } else {
                    $color_value = trim($settings[$option]);

                    // Add # prefix if missing
                    if (preg_match('/^[a-f0-9]{6}$/i', $color_value)) {
                        $color_value = '#' . $color_value;
                    }

                    $value = sanitize_hex_color($color_value);

                    // Only update if we have a valid hex color
                    if ($value) {
                        update_option($option, $value);
                    }
                }
            }
        }
    }

    /**
     * Render the settings page for this plugin.
     *
     * @since 1.1.6
     * @return void
     */
    public function display_admin_page()
    {
        // Get all settings with defaults
        $settings = $this->get_settings();

        // Determine which tab to show based on the current page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading GET parameter for tab display only
        $current_page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        $active_tab = $this->get_tab_from_page($current_page);
        $settings['active_tab'] = $active_tab;

        // Allow pro version to add additional settings
        $settings = apply_filters('dark_reader_admin_settings', $settings);

        // Include admin page template
        require_once Dark_Reader::get_instance()->get_plugin_dir() . 'admin/templates/templates.php';
    }

    /**
     * Get the tab ID from the page slug
     *
     * @since 1.1.6
     * @param string $page The page slug
     * @return string The tab ID
     */
    private function get_tab_from_page($page)
    {
        $tab_map = array(
            'dark-reader-settings' => 'dark-reader-tab-appearance',
            'dark-reader-toggle' => 'dark-reader-tab-toggle',
            'dark-reader-advanced' => 'dark-reader-tab-advanced',
            'dark-reader-colors' => 'dark-reader-tab-colors',
            'dark-reader-custom-css' => 'dark-reader-tab-pro-custom-css',
            'dark-reader-exclusions' => 'dark-reader-tab-pro-exclusions',
            'dark-reader-schedule' => 'dark-reader-tab-pro-schedule',
            'dark-reader-page-visibility' => 'dark-reader-tab-pro-page-visibility',
            'dark-reader-admin-dark-mode' => 'dark-reader-tab-pro-admin',
            'dark-reader-analytics' => 'dark-reader-tab-pro-analytics',
            'dark-reader-accessibility' => 'dark-reader-tab-pro-accessibility',
            'dark-reader-help' => 'dark-reader-tab-help',
            'dark-reader-export-import' => 'dark-reader-tab-export-import',
            'dark-reader-license' => 'dark-reader-tab-license',
        );

        return isset($tab_map[$page]) ? $tab_map[$page] : 'dark-reader-tab-appearance';
    }

    /**
     * Get all plugin settings with defaults.
     *
     * @since 1.1.6
     * @return array
     */
    private function get_settings()
    {
        return array(
            'version' => $this->version,
            'brightness' => intval(get_option($this->option_names['brightness'], 100)),
            'contrast' => intval(get_option($this->option_names['contrast'], 90)),
            'sepia' => intval(get_option($this->option_names['sepia'], 10)),
            'grayscale' => intval(get_option($this->option_names['grayscale'], 0)),
            'text_stroke' => floatval(get_option($this->option_names['text_stroke'], 0)),
            'filter_mode' => intval(get_option($this->option_names['filter_mode'], 1)),
            'default_dark_mode' => (bool) get_option($this->option_names['default_dark_mode'], false),
            'use_system_color_scheme' => (bool) get_option($this->option_names['use_system_color_scheme'], false),
            'enable_for_pdfs' => (bool) get_option($this->option_names['enable_for_pdfs'], false),
            'immediate_modify' => (bool) get_option($this->option_names['immediate_modify'], true),
            'dark_scheme_bg' => esc_attr(get_option($this->option_names['dark_scheme_background'], '')),
            'dark_scheme_text' => esc_attr(get_option($this->option_names['dark_scheme_text'], '')),
            'position' => esc_attr(get_option($this->option_names['toggle_position'], 'bottom-right')),
            'current_style' => $this->get_validated_toggle_style(),
        );
    }

    /**
     * Get validated toggle style with fallback for pro styles
     *
     * @return string The toggle style to use
     */
    private function get_validated_toggle_style(): string
    {
        $style = get_option($this->option_names['toggle_style'], 'default');

        // Pro styles that require valid license
        $pro_styles = ['modern-slider', 'text-toggle', 'flipflop-toggle', 'ios-toggle', 'ios-toggle-icon', 'liquid-glass', 'custom'];

        // If it's a pro style but pro is not active or license is invalid, fall back to default
        if (in_array($style, $pro_styles)) {
            if (!Dark_Reader::get_instance()->is_pro_active() || !Dark_Reader::get_instance()->has_valid_pro_license()) {
                $style = 'default';
                update_option($this->option_names['toggle_style'], 'default');
            }
        }

        return esc_attr($style);
    }

    /**
     * Pro option names excluded from settings export/import (site-specific data).
     *
     * @return string[]
     */
    private function get_pro_options_excluded_from_settings_backup(): array
    {
        return array('dark_reader_pro_analytics_data');
    }

    /**
     * Handle AJAX request to export settings
     *
     * @since 1.1.6
     * @return void
     */
    public function handle_export_settings()
    {
        // Check nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'dark_reader_admin_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed', 'dark-reader')));
        }

        // Check user capability
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => esc_html__('You do not have permission to export settings', 'dark-reader')));
        }

        // Collect all free version settings
        $settings = array(
            'version' => Dark_Reader::get_instance()->get_version(),
            'export_date' => current_time('mysql'),
            'free_settings' => array()
        );

        // Export all free version options
        foreach ($this->option_names as $key => $option_name) {
            $settings['free_settings'][$option_name] = get_option($option_name);
        }

        // If Pro is active, export Pro settings
        if (Dark_Reader::get_instance()->is_pro_active()) {
            $settings['pro_active'] = true;
            $settings['pro_settings'] = array();

            // Get all Pro options
            global $wpdb;
            $pro_options = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s",
                    'dark_reader_pro_%'
                )
            );

            // Deprecated color zone option patterns to exclude
            $deprecated_patterns = array(
                'dark_reader_pro_header_',
                'dark_reader_pro_sidebar_',
                'dark_reader_pro_content_',
                'dark_reader_pro_footer_',
                'dark_reader_pro_navigation_',
                'dark_reader_pro_buttons_',
                'dark_reader_pro_forms_',
                'dark_reader_pro_cards_',
                'dark_reader_pro_advanced_colors_enabled'
            );

            foreach ($pro_options as $option) {
                if (in_array($option->option_name, $this->get_pro_options_excluded_from_settings_backup(), true)) {
                    continue;
                }
                // Skip deprecated color zone options
                $is_deprecated = false;
                foreach ($deprecated_patterns as $pattern) {
                    if (strpos($option->option_name, $pattern) === 0 || $option->option_name === $pattern) {
                        $is_deprecated = true;
                        break;
                    }
                }

                if (!$is_deprecated) {
                    $settings['pro_settings'][$option->option_name] = maybe_unserialize($option->option_value);
                }
            }
        } else {
            $settings['pro_active'] = false;
        }

        // Send success response with settings data
        wp_send_json_success(array(
            'settings' => $settings,
            'filename' => 'dark-reader-settings-' . date('Y-m-d-His') . '.json'
        ));
    }

    /**
     * Handle AJAX request to import settings
     *
     * @since 1.1.6
     * @return void
     */
    public function handle_import_settings()
    {
        // Check nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'dark_reader_admin_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed', 'dark-reader')));
        }

        // Check user capability
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => esc_html__('You do not have permission to import settings', 'dark-reader')));
        }

        // Check if settings data is provided
        if (!isset($_POST['settings'])) {
            wp_send_json_error(array('message' => esc_html__('No settings data provided', 'dark-reader')));
        }

        // Decode JSON settings
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON data will be validated below
        $settings_json = wp_unslash($_POST['settings']);
        $settings = json_decode($settings_json, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(array('message' => esc_html__('Invalid JSON format', 'dark-reader')));
        }

        // Validate settings structure
        if (!isset($settings['free_settings']) || !is_array($settings['free_settings'])) {
            wp_send_json_error(array('message' => esc_html__('Invalid settings file format', 'dark-reader')));
        }

        $toggle_option_name = $this->option_names['toggle_style'];
        // When Pro data is imported, apply toggle style after Pro options so "custom" and its
        // dark_reader_pro_custom_* companion values are never briefly out of sync (avoids Pro
        // code resetting the toggle on the next request).
        $defer_toggle_style = Dark_Reader::get_instance()->is_pro_active()
            && isset($settings['pro_settings'])
            && is_array($settings['pro_settings'])
            && $settings['pro_settings'] !== array()
            && array_key_exists($toggle_option_name, $settings['free_settings']);

        // Import free version settings
        foreach ($settings['free_settings'] as $option_name => $option_value) {
            // Only import known option names for security
            if (!in_array($option_name, $this->option_names, true)) {
                continue;
            }
            if ($defer_toggle_style && $option_name === $toggle_option_name) {
                continue;
            }
            update_option($option_name, $option_value);
        }

        $message = esc_html__('Settings imported successfully', 'dark-reader');

        // Import Pro settings if Pro is active and settings contain Pro data
        if (Dark_Reader::get_instance()->is_pro_active() && isset($settings['pro_settings']) && is_array($settings['pro_settings'])) {
            // Deprecated color zone option patterns to exclude
            $deprecated_patterns = array(
                'dark_reader_pro_header_',
                'dark_reader_pro_sidebar_',
                'dark_reader_pro_content_',
                'dark_reader_pro_footer_',
                'dark_reader_pro_navigation_',
                'dark_reader_pro_buttons_',
                'dark_reader_pro_forms_',
                'dark_reader_pro_cards_',
                'dark_reader_pro_advanced_colors_enabled'
            );

            foreach ($settings['pro_settings'] as $option_name => $option_value) {
                if (in_array($option_name, $this->get_pro_options_excluded_from_settings_backup(), true)) {
                    continue;
                }
                // Only import options that start with dark_reader_pro_
                if (strpos($option_name, 'dark_reader_pro_') === 0) {
                    // Skip deprecated color zone options
                    $is_deprecated = false;
                    foreach ($deprecated_patterns as $pattern) {
                        if (strpos($option_name, $pattern) === 0 || $option_name === $pattern) {
                            $is_deprecated = true;
                            break;
                        }
                    }

                    if (!$is_deprecated) {
                        update_option($option_name, $option_value);
                    }
                }
            }
            $message = esc_html__('Settings imported successfully (including Pro settings)', 'dark-reader');
        } elseif (!Dark_Reader::get_instance()->is_pro_active() && isset($settings['pro_settings'])) {
            $message = esc_html__('Free settings imported successfully. Pro settings were skipped (Pro version not active)', 'dark-reader');
        }

        if ($defer_toggle_style) {
            update_option($toggle_option_name, $settings['free_settings'][$toggle_option_name]);
        }

        // Send success response
        wp_send_json_success(array('message' => $message));
    }
}

// Initialize the admin class
Dark_Reader_Admin::get_instance();
