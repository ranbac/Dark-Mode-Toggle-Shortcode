/**
 * Dark Reader Admin JavaScript
 * Handles admin UI interactions and animations
 * Modern implementation with ES6+ features
 */

(($) => {
  "use strict";

  // Initialize on document ready
  $(document).ready(() => {
    // Initialize all UI components
    initTabs();
    initColorPickers();
    initRangeSliders();
    initToggleButtons();
    initTooltips();
    initCopyShortcode();
    initTogglePreviewHover();
    initAjaxFormSubmit();
    initPositionToggles();
    initPageVisibilityControls();
    initSchedulerControls();
    initResetButton();
    initAdminDarkModeToggle();
    initSchedulerToggle();
    initExportSettings();
    initImportSettings();
    
    // Make external links in submenu open in new tab
    initExternalLinks();

    // Show save message on settings save
    if (window.location.search.includes("settings-updated=true")) {
      showSaveMessage();
    }
  });

  /**
   * Initialize tabs functionality
   */
  const initTabs = () => {
    // Hide all tab content initially
    $(".dark-reader-tab-content").hide();

    // Check if there's a server-side determined active tab (from menu navigation)
    const $activeNavTab = $(".dark-reader-nav-tab-active");
    const hasServerActiveTab = $activeNavTab.length > 0;
    
    let activeTab;
    
    if (hasServerActiveTab) {
      // Use the server-determined active tab (from clicking sidebar menu)
      activeTab = $activeNavTab.attr("href");
      // Clear localStorage since we're navigating via menu
      localStorage.removeItem("darkReaderActiveTab");
    } else {
      // Fall back to localStorage only if no server-side active tab
      const savedTab = localStorage.getItem("darkReaderActiveTab");
      if (savedTab && $(savedTab).length) {
        activeTab = savedTab;
        $(`.dark-reader-nav-tab[href="${savedTab}"]`).addClass("dark-reader-nav-tab-active");
      } else {
        activeTab = "#dark-reader-tab-appearance";
        $(`.dark-reader-nav-tab[href="${activeTab}"]`).addClass("dark-reader-nav-tab-active");
      }
    }
    
    // Show the active tab
    $(activeTab).addClass("dark-reader-tab-content-active").show();

    // Hide save button if we're on the License or Export/Import tab
    if (activeTab === "#dark-reader-tab-license" || activeTab === "#dark-reader-tab-export-import") {
      $("#dark-reader-save-btn").hide();
    } else {
      $("#dark-reader-save-btn").show();
    }

    // Handle tab clicks
    $(".dark-reader-nav-tab").on("click", (e) => {
      e.preventDefault();

      // Get the tab target
      const target = $(e.currentTarget).attr("href");

      // Map tab hash to page URL
      const tabToPageMap = {
        '#dark-reader-tab-appearance': 'dark-reader-settings',
        '#dark-reader-tab-toggle': 'dark-reader-toggle',
        '#dark-reader-tab-advanced': 'dark-reader-advanced',
        '#dark-reader-tab-colors': 'dark-reader-colors',
        '#dark-reader-tab-pro-custom-css': 'dark-reader-custom-css',
        '#dark-reader-tab-pro-exclusions': 'dark-reader-exclusions',
        '#dark-reader-tab-pro-schedule': 'dark-reader-schedule',
        '#dark-reader-tab-pro-page-visibility': 'dark-reader-page-visibility',
        '#dark-reader-tab-pro-admin': 'dark-reader-admin-dark-mode',
        '#dark-reader-tab-pro-analytics': 'dark-reader-analytics',
        '#dark-reader-tab-pro-accessibility': 'dark-reader-accessibility',
        '#dark-reader-tab-help': 'dark-reader-help',
        '#dark-reader-tab-export-import': 'dark-reader-export-import',
        '#dark-reader-tab-license': 'dark-reader-license'
      };

      // Get the page slug for this tab
      const pageSlug = tabToPageMap[target];
      
      // Update URL without page reload using History API
      if (pageSlug) {
        const newUrl = 'admin.php?page=' + pageSlug;
        window.history.pushState({tab: target}, '', newUrl);
        
        // Update admin menu highlighting
        updateAdminMenuHighlight(pageSlug);
      }

      // Handle save button visibility
      if (target === "#dark-reader-tab-license" || target === "#dark-reader-tab-export-import") {
        $("#dark-reader-save-btn").hide();
      } else {
        $("#dark-reader-save-btn").show();
      }

      // Remove active class from all tabs
      $(".dark-reader-nav-tab").removeClass("dark-reader-nav-tab-active");
      $(".dark-reader-tab-content")
        .removeClass("dark-reader-tab-content-active")
        .hide();

      // Add active class to all nav tabs with the same target (sidebar and header)
      $(`.dark-reader-nav-tab[href="${target}"]`).addClass("dark-reader-nav-tab-active");
      $(target).addClass("dark-reader-tab-content-active").show();

      // Save the active tab in localStorage (only for within-page navigation)
      localStorage.setItem("darkReaderActiveTab", target);
    });

    $('.dark-reader-widget-info-icon').on('click', (e) => {
      e.preventDefault();
      $('a[href="#dark-reader-tab-help"]').trigger("click");
    })
  };

  /**
   * Initialize WordPress color pickers
   */
  const initColorPickers = () => {
    // Initialize WordPress color picker
    $(".dark-reader-color-picker").wpColorPicker({
      change: (event, ui) => {
        // Update the color preview
        const preview = $(event.target)
          .closest(".dark-reader-color-picker-wrapper")
          .find(".dark-reader-color-preview");
        preview.css("background-color", ui.color.toString());

        // Update the hidden input value to ensure it's included in form submission
        $(event.target).val(ui.color.toString()).trigger("change");
      },
      clear: (event) => {
        // Clear the preview when color is cleared
        const preview = $(event.target)
          .closest(".dark-reader-color-picker-wrapper")
          .find(".dark-reader-color-preview");
        preview.css("background-color", "");

        // Also clear the input value
        $(event.target).val("").trigger("change");
        $(event.target)
          .closest(".wp-picker-input-wrap")
          .find(".button.button-small.wp-picker-clear")
          .val("Clear");
      },
    });

    // Set initial color previews
    $(".dark-reader-color-picker").each(function () {
      const color = $(this).val();
      if (color) {
        const preview = $(this)
          .closest(".dark-reader-color-picker-wrapper")
          .find(".dark-reader-color-preview");
        preview.css("background-color", color);
      }
    });
  };

  /**
   * Initialize range slider functionality
   */
  const initRangeSliders = () => {
    // Handle standard range sliders
    $('.dark-reader-range-slider input[type="range"]').on("input", function () {
      const value = $(this).val();
      const valueDisplay = $(this)
        .closest(".dark-reader-range-slider-control")
        .find(".dark-reader-range-slider-value");

      // Check if this is the text stroke range slider
      if ($(this).attr("name") === "dark_reader_text_stroke") {
        valueDisplay.text(`${value}px`);
      } else {
        valueDisplay.text(`${value}%`);
      }
    });

    // Handle admin brightness and contrast sliders
    $("#admin-brightness").on("input", function () {
      const value = $(this).val();
      $("#admin-brightness-value").text(`${value}%`);
    });

    $("#admin-contrast").on("input", function () {
      const value = $(this).val();
      $("#admin-contrast-value").text(`${value}%`);
    });
  };

  /**
   * Initialize toggle button style selector
   */
  const initToggleButtons = () => {
    $(".dark-reader-style-option").on("click", function () {
      // Remove selected class from all options
      $(".dark-reader-style-option").removeClass("selected");

      // Add selected class to clicked option
      $(this).addClass("selected");

      // Check the radio button
      $(this).find('input[type="radio"]').prop("checked", true);
    });
  };

  /**
   * Make toggle button previews interactive on hover
   */
  const initTogglePreviewHover = () => {
    // Show dark mode preview on hover
    $(".dark-reader-style-option").hover(
      function () {
        // On mouseenter - show dark mode
        const preview = $(this).find(".dark-reader-style-preview");

        // Default & Round styles
        if (preview.hasClass("default") || preview.hasClass("round")) {
          $(this).find(".preview-icon").text("🌙");
        }

        // Switch style
        if (preview.hasClass("switch")) {
          $(this).find(".preview-track").css("background-color", "#4CAF50");
          $(this).find(".preview-thumb").css("transform", "translateX(27px)");
        }

        // Toggle style
        if (preview.hasClass("toggle")) {
          $(this)
            .find(".preview-toggle-track")
            .css("background-color", "#292c35");
          $(this)
            .find(".preview-toggle-thumb")
            .css("transform", "translateX(32px)");
        }

        // Minimal style
        if (preview.hasClass("minimal")) {
          $(this).find(".preview-button.minimal").attr("style", "background-color: black !important; border: 1px solid white !important;");
          $(this).find(".preview-minimal-icon").attr("style", "transform: rotate(225deg) !important; transition: transform 0.5s ease !important; background: linear-gradient(135deg, #ffffffff 50%, rgba(0, 0, 0, 1) 50%) !important;");
        }

        // Slider style
        // if (preview.hasClass("slider")) {
        //   $(this).find(".preview-slider-background").css({
        //     "background": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        //     "border": "1px solid #ffffff",
        //     "box-shadow": "0 2px 8px rgba(0, 0, 0, 0.2)"
        //   });
        //   $(this).find(".preview-slider-thumb").css("transform", "translateX(44px)");
        //   $(this).find(".preview-slider-sun").css({ opacity: "1", transform: "scale(1)" });
        //   $(this).find(".preview-slider-moon").css({ opacity: "0.4", transform: "scale(0.9)" });
        // }
      },
      function () {
        // On mouseleave - show light mode
        const preview = $(this).find(".dark-reader-style-preview");

        // Default & Round styles
        if (preview.hasClass("default") || preview.hasClass("round")) {
          $(this).find(".preview-icon").text("☀️");
        }

        // Switch style
        if (preview.hasClass("switch")) {
          $(this).find(".preview-track").css("background-color", "#ccc");
          $(this).find(".preview-thumb").css("transform", "translateX(0)");
        }

        // Toggle style
        if (preview.hasClass("toggle")) {
          $(this)
            .find(".preview-toggle-track")
            .css("background-color", "#f1f1f1");
          $(this)
            .find(".preview-toggle-thumb")
            .css("transform", "translateX(0)");
        }

        // Minimal style
        if (preview.hasClass("minimal")) {
          $(this).find(".preview-button.minimal").attr("style", "background-color: #f8f8f8 !important; border: none !important;");
          $(this).find(".preview-minimal-icon").attr("style", "transform: rotate(45deg) !important; transition: transform 0.5s ease !important; background: linear-gradient(135deg, #f8f8f8 50%, #333 50%) !important;");
        }

        // Slider style
        // if (preview.hasClass("slider")) {
        //   $(this).find(".preview-slider-background").css({
        //     "background": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        //     "border": "none",
        //     "box-shadow": "0 2px 8px rgba(0, 0, 0, 0.15)"
        //   });
        //   $(this).find(".preview-slider-thumb").css("transform", "translateX(0)");
        //   $(this).find(".preview-slider-sun").css({ opacity: "0.4", transform: "scale(0.9)" });
        //   $(this).find(".preview-slider-moon").css({ opacity: "1", transform: "scale(1)" });
        // }
      }
    );
  };

  /**
   * Initialize AJAX form submission
   */
  const initAjaxFormSubmit = () => {
    // Settings form
    const $form = $(".dark-reader-main > form");
    const $submitBtn = $(".dark-reader-submit-btn");

    // Handle form submission
    $form.on("submit", function (e) {
      e.preventDefault();

      // Ensure color picker values are collected correctly
      // The WordPress color picker creates a hidden input, so we need to make sure
      // the values are correctly set before serializing
      $(".dark-reader-color-picker").each(function () {
        const $this = $(this);
        const $wpColorPickerInput = $this
          .closest(".wp-picker-container")
          .find(".wp-color-picker");

        // If the color picker is initialized, get the value from the actual visible input
        if ($wpColorPickerInput.length) {
          const colorValue = $wpColorPickerInput.val();
          $this.val(colorValue);
        }
      });

      // Change button state
      $submitBtn.prop("disabled", true).addClass("saving");

      // Prepare data for AJAX submission
      const formData = $(this).serialize();

      // Send AJAX request
      $.ajax({
        url: ajaxurl,
        type: "POST",
        data: {
          action: "dark_reader_save_settings",
          nonce: darkReaderAdmin.nonce,
          settings: formData,
        },
        success: (response) => {
          // Reset button state
          $submitBtn.prop("disabled", false).removeClass("saving");

          // Show success message
          if (response.success) {
            showSaveMessage();
          } else {
            showErrorMessage(response.data.message || "Error saving settings");
          }
        },
        error: () => {
          // Reset button state
          $submitBtn.prop("disabled", false).removeClass("saving");

          // Show error message
          showErrorMessage("Error saving settings. Please try again.");
        },
      });
    });
  };

  /**
   * Initialize tooltips with mobile-friendly behavior
   */
  const initTooltips = () => {
    // Mobile-friendly tooltips that work with touch
    $(".dark-reader-tooltip").on("click", (e) => {
      e.preventDefault();

      const tooltip = $(e.currentTarget).find(".dark-reader-tooltip-text");

      // Hide all other tooltips
      $(".dark-reader-tooltip-text").not(tooltip).css("visibility", "hidden");

      // Toggle visibility of clicked tooltip
      if (tooltip.css("visibility") === "visible") {
        tooltip.css("visibility", "hidden");
      } else {
        tooltip.css("visibility", "visible");
      }
    });

    // Hide tooltips when clicking elsewhere
    $(document).on("click", (e) => {
      if (!$(e.target).closest(".dark-reader-tooltip").length) {
        $(".dark-reader-tooltip-text").css("visibility", "hidden");
      }
    });
  };

  /**
   * Initialize copy shortcode functionality
   */
  const initCopyShortcode = () => {
    $(".dark-reader-copy-btn").on("click", function (e) {
      e.preventDefault(); // Prevent any default button behavior
      
      const $button = $(this);
      const shortcode = $button
        .closest(".dark-reader-shortcode-display")
        .find("code")
        .text();

      // Prevent multiple clicks while animation is in progress
      if ($button.hasClass("copying")) {
        return;
      }

      // Use modern clipboard API if available, fallback to execCommand
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard
          .writeText(shortcode)
          .then(() => showCopySuccess($button))
          .catch(() => fallbackCopy($button, shortcode));
      } else {
        fallbackCopy($button, shortcode);
      }
    });
  };

  /**
   * Fallback copy method for older browsers
   */
  const fallbackCopy = ($button, text) => {
    // Create a temporary input element
    const tempInput = $("<input>");
    $("body").append(tempInput);
    tempInput.val(text).select();

    // Try to copy using the deprecated execCommand as fallback for older browsers
    try {
      // @ts-ignore: Intentionally using deprecated API for backward compatibility
      document.execCommand("copy");
    } catch (err) {}

    tempInput.remove();

    // Show success animation
    showCopySuccess($button);
  };

  /**
   * Show copy success animation
   */
  const showCopySuccess = ($button) => {
    // Mark button as copying to prevent multiple clicks
    $button.addClass("copying");

    const $textSpan = $button.find("span:not(.dark-reader-checkmark)");
    const originalText = $textSpan.text();
    const checkmark = $button.find(".dark-reader-checkmark");

    // Animate checkmark and update text
    checkmark.addClass("animate");
    $textSpan.text("Copied!");

    // Reset after a delay
    setTimeout(() => {
      checkmark.removeClass("animate");
      $textSpan.text(originalText);
      $button.removeClass("copying");
    }, 2000);
  };

  /**
   * Show a generic success notification (save, export, import, etc.)
   *
   * @param {string} [message='Your settings have been saved']
   * @param {string} [title='Success!']
   */
  const showSaveMessage = (message = "Your settings have been saved", title = "Success!") => {
    // Remove any existing notifications
    $(".dark-reader-notification").remove();

    // Create modern notification element
    const notification = $(`
            <div class="dark-reader-notification">
                <div class="dark-reader-notification-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                        <path d="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z" fill="#4CAF50"/>
                    </svg>
                </div>
                <div class="dark-reader-notification-content">
                    <div class="dark-reader-notification-title"></div>
                    <div class="dark-reader-notification-message"></div>
                </div>
                <button class="dark-reader-notification-close">×</button>
            </div>
        `);
    notification.find(".dark-reader-notification-title").text(title);
    notification.find(".dark-reader-notification-message").text(message);

    // Add to the document body
    $("body").append(notification);

    // Show the notification with animation
    setTimeout(() => {
      notification.addClass("show");
    }, 10);

    // Handle close button click
    notification
      .find(".dark-reader-notification-close")
      .on("click", function () {
        notification.removeClass("show");
        setTimeout(() => notification.remove(), 300);
      });

    // Auto remove after 4 seconds
    setTimeout(() => {
      notification.removeClass("show");
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  };

  /**
   * Show error message when settings save fails
   */
  const showErrorMessage = (errorText) => {
    // Remove any existing notifications
    $(".dark-reader-notification").remove();

    // Create modern notification element
    const notification = $(`
            <div class="dark-reader-notification dark-reader-notification-error">
                <div class="dark-reader-notification-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                        <path d="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M12 14C11.4 14 11 13.6 11 13V7C11 6.4 11.4 6 12 6S13 6.4 13 7V13C13 13.6 12.6 14 12 14M12 18C11.4 18 11 17.6 11 17S11.4 16 12 16 13 16.4 13 17 12.6 18 12 18Z" fill="#F44336"/>
                    </svg>
                </div>
                <div class="dark-reader-notification-content">
                    <div class="dark-reader-notification-title">Error</div>
                    <div class="dark-reader-notification-message">${errorText}</div>
                </div>
                <button class="dark-reader-notification-close">×</button>
            </div>
        `);

    // Add to the document body
    $("body").append(notification);

    // Show the notification with animation
    setTimeout(() => {
      notification.addClass("show");
    }, 10);

    // Handle close button click
    notification
      .find(".dark-reader-notification-close")
      .on("click", function () {
        notification.removeClass("show");
        setTimeout(() => notification.remove(), 300);
      });

    // Auto remove after 6 seconds
    setTimeout(() => {
      notification.removeClass("show");
      setTimeout(() => notification.remove(), 300);
    }, 6000);
  };

  /**
   * Initialize position toggle buttons
   */
  const initPositionToggles = () => {
    const toggleButtons = document.querySelectorAll(".position-toggle-btn");
    const hiddenInput = document.getElementById("dark_reader_toggle_position");

    if (!toggleButtons.length || !hiddenInput) return;

    toggleButtons.forEach((button) => {
      button.addEventListener("click", function () {
        // Remove active class from all buttons
        toggleButtons.forEach((btn) => btn.classList.remove("active"));

        // Add active class to clicked button
        this.classList.add("active");

        // Update hidden input value
        const position = this.getAttribute("data-position");
        hiddenInput.value = position;
      });
    });
  };

  /**
   * Initialize page visibility controls (Pro feature)
   */
  const initPageVisibilityControls = () => {
    const $visibilityModeSelect = $(
      'select[name="dark_reader_pro_page_visibility_mode"]'
    );
    const $dependentRows = $(".dark-reader-page-visibility-dependent");

    if (!$visibilityModeSelect.length) {
      return;
    }

    // Function to toggle visibility of related controls with smooth transitions
    const togglePageVisibilityControls = () => {
      const selectedMode = $visibilityModeSelect.val();

      if (selectedMode === "show_all" || selectedMode === "hide_all") {
        // Hide page types and specific pages when showing on all pages or hiding on all pages
        $dependentRows.removeClass("enabled").addClass("disabled");
      } else {
        // Show page types and specific pages for selective modes
        $dependentRows.removeClass("disabled").addClass("enabled");
      }
    };

    // Set initial state based on current selection
    togglePageVisibilityControls();

    // Listen for changes
    $visibilityModeSelect.on("change", togglePageVisibilityControls);
  };

  /**
   * Initialize reset button functionality
   */
  const initResetButton = () => {
    $("#dark-reader-reset-appearance").on("click", function () {
      // Reset values to default
      const defaultValues = {
        dark_reader_brightness: 100,
        dark_reader_contrast: 90,
        dark_reader_sepia: 10,
        dark_reader_grayscale: 0,
      };

      // Update all range sliders and their value displays
      Object.keys(defaultValues).forEach((inputName) => {
        const $input = $(`input[name="${inputName}"]`);
        const $valueDisplay = $input
          .closest(".dark-reader-range-slider-control")
          .find(".dark-reader-range-slider-value");

        $input.val(defaultValues[inputName]);
        $valueDisplay.text(`${defaultValues[inputName]}%`);
      });

      // Show a brief notification that values have been reset
      showResetMessage();
    });
  };

  /**
   * Show save message when settings are saved successfully
   */
  const showResetMessage = () => {
    // Remove any existing notifications
    $(".dark-reader-notification").remove();

    // Create modern notification element
    const notification = $(`
            <div class="dark-reader-notification">
                <div class="dark-reader-notification-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                        <path d="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z" fill="#4CAF50"/>
                    </svg>
                </div>
                <div class="dark-reader-notification-content">
                    <div class="dark-reader-notification-title">Success!</div>
                    <div class="dark-reader-notification-message">Appearance settings reset</div>
                </div>
                <button class="dark-reader-notification-close">×</button>
            </div>
        `);

    // Add to the document body
    $("body").append(notification);

    // Show the notification with animation
    setTimeout(() => {
      notification.addClass("show");
    }, 10);

    // Handle close button click
    notification
      .find(".dark-reader-notification-close")
      .on("click", function () {
        notification.removeClass("show");
        setTimeout(() => notification.remove(), 300);
      });

    // Auto remove after 4 seconds
    setTimeout(() => {
      notification.removeClass("show");
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  };

  /**
   * Initialize scheduler controls functionality
   * Shows/hides time fields based on schedule type selection
   */
  const initSchedulerControls = () => {
    const $scheduleTypeSelect = $(
      'select[name="dark_reader_pro_schedule_type"]'
    );
    const $timeControls = $(".dark-reader-scheduler-time-dependent");
    const $infoRow = $(".schedule-info-row");

    if (!$scheduleTypeSelect.length) {
      return;
    }

    // Function to toggle visibility of time controls and info row with smooth transitions
    const toggleTimeControls = () => {
      const selectedType = $scheduleTypeSelect.val();

      if (selectedType === "time") {
        // Show time controls for time-based scheduling
        $timeControls.removeClass("disabled").addClass("enabled");
        $infoRow.removeClass("enabled").addClass("disabled");
      } else {
        // Hide time controls for system preference and sunset/sunrise
        $timeControls.removeClass("enabled").addClass("disabled");
        $infoRow.removeClass("disabled").addClass("enabled");
      }
    };

    // Set initial state based on current selection
    toggleTimeControls();

    // Listen for changes
    $scheduleTypeSelect.on("change", toggleTimeControls);
  };

  /**
   * Initialize admin dark mode toggle functionality
   * Shows/hides dependent settings based on main toggle state
   */
  const initAdminDarkModeToggle = () => {
    const $adminToggle = $("#admin-dark-mode-toggle");
    const $dependentRows = $(".dark-reader-admin-dependent");

    if (!$adminToggle.length) {
      return;
    }

    // Function to update dependent settings visibility
    const updateDependentSettings = (isEnabled) => {
      $dependentRows.each(function() {
        const $row = $(this);
        if (isEnabled) {
          $row.removeClass("disabled").addClass("enabled");
        } else {
          $row.removeClass("enabled").addClass("disabled");
        }
      });
    };

    // Set initial state based on checkbox value
    updateDependentSettings($adminToggle.is(":checked"));

    // Listen for toggle changes
    $adminToggle.on("change", function() {
      const isEnabled = $(this).is(":checked");
      updateDependentSettings(isEnabled);
    });
  };

  /**
   * Initialize scheduler toggle functionality
   * Shows/hides dependent settings based on scheduler enable toggle state
   */
  const initSchedulerToggle = () => {
    const $schedulerToggle = $("#schedule-enabled-toggle");
    const $dependentRows = $(".dark-reader-scheduler-dependent");

    if (!$schedulerToggle.length) {
      return;
    }

    // Function to update dependent settings visibility
    const updateSchedulerSettings = (isEnabled) => {
      $dependentRows.each(function() {
        const $row = $(this);
        if (isEnabled) {
          $row.removeClass("disabled").addClass("enabled");
        } else {
          $row.removeClass("enabled").addClass("disabled");
        }
      });
      
      // If scheduler is disabled, also hide time controls and show info row
      if (!isEnabled) {
        $(".dark-reader-scheduler-time-dependent").removeClass("enabled").addClass("disabled");
        $(".schedule-info-row").removeClass("enabled").addClass("disabled");
      } else {
        // If scheduler is enabled, let the schedule type control handle visibility
        const selectedType = $('select[name="dark_reader_pro_schedule_type"]').val();
        if (selectedType === "time") {
          $(".dark-reader-scheduler-time-dependent").removeClass("disabled").addClass("enabled");
          $(".schedule-info-row").removeClass("enabled").addClass("disabled");
        } else {
          $(".dark-reader-scheduler-time-dependent").removeClass("enabled").addClass("disabled");
          $(".schedule-info-row").removeClass("disabled").addClass("enabled");
        }
      }
    };

    // Set initial state based on checkbox value
    updateSchedulerSettings($schedulerToggle.is(":checked"));

    // Listen for toggle changes
    $schedulerToggle.on("change", function() {
      const isEnabled = $(this).is(":checked");
      updateSchedulerSettings(isEnabled);
    });
  };

  /**
   * Update admin menu highlighting based on current page
   */
  const updateAdminMenuHighlight = (pageSlug) => {
    // Remove current/active classes from all Dark Reader submenu items
    $('#adminmenu #toplevel_page_dark-reader-settings .wp-submenu li').removeClass('current');
    
    // Add current class to the matching submenu item
    $('#adminmenu #toplevel_page_dark-reader-settings .wp-submenu a').each(function() {
      const href = $(this).attr('href');
      if (href && href.includes('page=' + pageSlug)) {
        $(this).parent('li').addClass('current');
      }
    });
  };

  /**
   * Handle browser back/forward buttons
   */
  window.addEventListener('popstate', function(event) {
    if (event.state && event.state.tab) {
      // Get the tab from the state
      const tab = event.state.tab;
      
      // Trigger click on the corresponding tab
      $(`.dark-reader-nav-tab[href="${tab}"]`).trigger('click');
    }
  });

  /**
   * Make external links in Dark Reader submenu open in new tab
   */
  const initExternalLinks = () => {
    // Target external links in the Dark Reader submenu (bdthemes.com links)
    $('#adminmenu #toplevel_page_dark-reader-settings .wp-submenu a[href*="bdthemes.com"]').each(function() {
      $(this).attr('target', '_blank');
      $(this).attr('rel', 'noopener noreferrer');
    });
  };

  /**
   * Initialize export settings functionality
   */
  const initExportSettings = () => {
    $('#dark-reader-export-settings').on('click', function(e) {
      e.preventDefault();
      
      const $button = $(this);
      const originalText = $button.html();
      
      // Disable button and show loading state
      $button.prop('disabled', true).html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="spinning"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg> Exporting...');
      
      // Send AJAX request to export settings
      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'dark_reader_export_settings',
          nonce: darkReaderAdmin.nonce
        },
        success: function(response) {
          if (response.success) {
            // Create a blob from the settings data
            const settingsJson = JSON.stringify(response.data.settings, null, 2);
            const blob = new Blob([settingsJson], { type: 'application/json' });
            const url = window.URL.createObjectURL(blob);
            
            // Create a temporary download link and trigger it
            const a = document.createElement('a');
            a.href = url;
            a.download = response.data.filename;
            document.body.appendChild(a);
            a.click();
            
            // Clean up
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            // Show success message
            showSaveMessage("Your settings file has been downloaded.");
          } else {
            showErrorMessage(response.data.message || 'Failed to export settings');
          }
          
          // Reset button
          $button.prop('disabled', false).html(originalText);
        },
        error: function() {
          showErrorMessage('Failed to export settings. Please try again.');
          $button.prop('disabled', false).html(originalText);
        }
      });
    });
  };

  /**
   * Initialize import settings functionality
   */
  const initImportSettings = () => {
    const $importButton = $('#dark-reader-import-settings');
    const $fileInput = $('#dark-reader-import-file');
    const $statusDiv = $('#dark-reader-import-status');
    
    // Trigger file input when button is clicked
    $importButton.on('click', function(e) {
      e.preventDefault();
      $fileInput.click();
    });
    
    // Handle file selection
    $fileInput.on('change', function(e) {
      const file = e.target.files[0];
      
      if (!file) {
        return;
      }
      
      // Validate file type
      if (!file.name.endsWith('.json')) {
        $statusDiv.html('<p style="color: #d63638;">Please select a valid JSON file.</p>');
        return;
      }
      
      // Read the file
      const reader = new FileReader();
      
      reader.onload = function(event) {
        try {
          // Parse JSON to validate it
          const settings = JSON.parse(event.target.result);
          
          // Show loading state
          $statusDiv.html('<p style="color: #2271b1;">Importing settings...</p>');
          
          // Send AJAX request to import settings
          $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
              action: 'dark_reader_import_settings',
              nonce: darkReaderAdmin.nonce,
              settings: JSON.stringify(settings)
            },
            success: function(response) {
              if (response.success) {
                $statusDiv.html('<p style="color: #00a32a;">' + response.data.message + '</p>');
                
                // Show success notification
                showSaveMessage(
                  response.data.message || "Settings imported successfully."
                );
                
                // Reload page after 2 seconds to reflect imported settings
                setTimeout(function() {
                  window.location.reload();
                }, 2000);
              } else {
                $statusDiv.html('<p style="color: #d63638;">' + response.data.message + '</p>');
              }
            },
            error: function() {
              $statusDiv.html('<p style="color: #d63638;">Failed to import settings. Please try again.</p>');
            }
          });
        } catch (error) {
          $statusDiv.html('<p style="color: #d63638;">Invalid JSON file. Please select a valid Dark Reader settings file.</p>');
        }
      };
      
      reader.onerror = function() {
        $statusDiv.html('<p style="color: #d63638;">Failed to read file. Please try again.</p>');
      };
      
      reader.readAsText(file);
      
      // Reset file input
      $fileInput.val('');
    });
  };
})(jQuery);
